package com.lendrix.notificationservice.controller;

import com.lendrix.notificationservice.dto.NotificationDTO;
import com.lendrix.notificationservice.service.EmailService;
import com.lendrix.notificationservice.service.SMSService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller responsible for handling notification requests.
 * <p>
 * This controller exposes an endpoint to send notifications via email or SMS
 * based on the type specified in the {@link NotificationDTO}.
 * </p>
 * <p>
 * Supported notification types:
 * <ul>
 *     <li><b>EMAIL</b>: Sends an email notification using {@link EmailService}.</li>
 *     <li><b>SMS</b>: Sends an SMS notification using {@link SMSService}.</li>
 * </ul>
 * </p>
 * <p>
 * If an unsupported type is provided, the controller throws an {@link IllegalArgumentException}.
 * </p>
 * 
 * <p><b>Endpoint:</b></p>
 * <ul>
 *     <li><code>POST /api/notify</code> - Accepts a JSON body representing a {@link NotificationDTO}</li>
 * </ul>
 * 
 * <p><b>Example request body:</b></p>
 * <pre>
 * {
 *   "type": "EMAIL",
 *   "to": "user@example.com",
 *   "subject": "Verification",
 *   "message": "Your code is 1234"
 * }
 * </pre>
 * 
 * <p><b>Example response:</b> "✅ Email sent" or "✅ SMS sent"</p>
 * 
 * @author 
 */
@RestController
@RequestMapping("/api/notify")
public class NotificationController {

    @Autowired
    private EmailService emailService;

    @Autowired
    private SMSService smsService;

    /**
     * Sends a notification based on the type specified in the NotificationDTO.
     * <p>
     * The method delegates to the appropriate service to send either an email or SMS.
     * </p>
     *
     * @param dto the {@link NotificationDTO} containing notification details
     * @return a success message indicating the type of notification sent
     * @throws IllegalArgumentException if the notification type is unsupported
     */
    @PostMapping
    public String sendNotification(@RequestBody NotificationDTO dto) {
        switch (dto.getType().toUpperCase()) {
            case "EMAIL" -> {
                emailService.sendEmail(dto);
                return "✅ Email sent";
            }
            case "SMS" -> {
                smsService.sendSms(dto);
                return "✅ SMS sent";
            }
            default -> throw new IllegalArgumentException("❌ Unsupported type: " + dto.getType());
        }
    }
}
