package com.lendrix.notificationservice.entity;

import java.time.LocalDateTime;

import com.lendrix.notificationservice.enums.NotificationType;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Represents a log entry for a sent notification (Email or SMS).
 * Stores recipient info, message, subject (for email), type, and send time.
 */
@Entity
@Table(name = "notification_logs")
public class NotificationLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String recipient;

    private String message;

    private String subject; // only for email

    @Enumerated(EnumType.STRING)
    private NotificationType type;

    private LocalDateTime sentAt;

    public NotificationLog() {}

    public NotificationLog(String recipient, String message, String subject, NotificationType type, LocalDateTime sentAt) {
        this.recipient = recipient;
        this.message = message;
        this.subject = subject;
        this.type = type;
        this.sentAt = sentAt;
    }

    public Long getId() { return id; }
    public String getRecipient() { return recipient; }
    public void setRecipient(String recipient) { this.recipient = recipient; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    public NotificationType getType() { return type; }
    public void setType(NotificationType type) { this.type = type; }
    public LocalDateTime getSentAt() { return sentAt; }
    public void setSentAt(LocalDateTime sentAt) { this.sentAt = sentAt; }
}