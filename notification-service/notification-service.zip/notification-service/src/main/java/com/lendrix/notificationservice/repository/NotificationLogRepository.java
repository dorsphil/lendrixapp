
package com.lendrix.notificationservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lendrix.notificationservice.entity.NotificationLog;

/**
 * Repository interface for storing and accessing NotificationLog records.
 */
@Repository
public interface NotificationLogRepository extends JpaRepository<NotificationLog, Long> {
}
