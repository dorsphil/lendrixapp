package com.lendrix.notificationservice.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.lendrix.notificationservice.entity.NotificationLog;
import com.lendrix.notificationservice.enums.NotificationType;

/**
 * Repository interface for managing NotificationLog entities.
 * <p>
 * This repository provides CRUD operations and custom query methods
 * for accessing notification log data from the database.
 * </p>
 * 
 * @author [Your Name]
 */
@Repository
public interface NotificationRepository extends JpaRepository<NotificationLog, Long> {
    
    /**
     * Find all notification logs by recipient.
     * 
     * @param recipient the recipient's email or phone number
     * @return list of notification logs for the recipient
     */
    List<NotificationLog> findByRecipient(String recipient);
    
    /**
     * Find all notification logs by type.
     * 
     * @param type the notification type (EMAIL or SMS)
     * @return list of notification logs of the specified type
     */
    List<NotificationLog> findByType(NotificationType type);
    
    /**
     * Find all notification logs sent between two dates.
     * 
     * @param startDate the start date
     * @param endDate the end date
     * @return list of notification logs sent within the date range
     */
    List<NotificationLog> findBySentAtBetween(LocalDateTime startDate, LocalDateTime endDate);
    
    /**
     * Find all notification logs by recipient and type.
     * 
     * @param recipient the recipient's email or phone number
     * @param type the notification type
     * @return list of notification logs matching both criteria
     */
    List<NotificationLog> findByRecipientAndType(String recipient, NotificationType type);
    
    /**
     * Count total notifications sent by type.
     * 
     * @param type the notification type
     * @return count of notifications of the specified type
     */
    long countByType(NotificationType type);
    
    /**
     * Find recent notification logs (last 24 hours).
     * 
     * @param since the datetime to search from
     * @return list of recent notification logs
     */
    @Query("SELECT n FROM NotificationLog n WHERE n.sentAt >= :since ORDER BY n.sentAt DESC")
    List<NotificationLog> findRecentLogs(@Param("since") LocalDateTime since);
}