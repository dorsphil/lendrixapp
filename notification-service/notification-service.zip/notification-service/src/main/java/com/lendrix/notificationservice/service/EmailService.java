package com.lendrix.notificationservice.service;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.lendrix.notificationservice.dto.NotificationDTO;
import com.lendrix.notificationservice.entity.NotificationLog;
import com.lendrix.notificationservice.enums.NotificationType;
import com.lendrix.notificationservice.repository.NotificationLogRepository;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

/**
 * Service responsible for sending emails via SMTP.
 * <p>
 * This service handles the process of constructing and sending email messages
 * to users. It also records each sent (or failed) notification to the database
 * for audit and tracking purposes. Uses the SMTP protocol through JavaMailSender.
 * </p>
 * 
 * <p><b>Typical usage example:</b></p>
 * <pre>
 *     @Autowired
 *     private EmailService emailService;
 *
 *     emailService.sendEmail("recipient@example.com", "Subject", "Message body");
 * </pre>
 * 
 * @author [Your Name]
 */
@Service
public class EmailService {

    private static final Logger log = LoggerFactory.getLogger(EmailService.class);

    private final JavaMailSender mailSender;
    private final NotificationLogRepository logRepository;

    // Define the from address - can be configured via application.properties
    @Value("${spring.mail.from:lendrixapp@gmail.com}")
    private String fromAddress;

    public EmailService(JavaMailSender mailSender, NotificationLogRepository logRepository) {
        this.mailSender = mailSender;
        this.logRepository = logRepository;
    }

    /**
     * Sends an email based on the information provided in the given NotificationDTO.
     * <p>
     * This method constructs a simple email message using the recipient's address,
     * subject, and message body defined in the DTO. The email is sent from a configured
     * sender address. If the email fails to send, the exception is logged and rethrown
     * as a RuntimeException.
     * </p>
     *
     * @param dto the {@link NotificationDTO} containing email details such as recipient address,
     *            subject, and message body
     * @throws RuntimeException if sending the email fails for any reason
     */
    public void sendEmail(NotificationDTO dto) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(dto.getTo());
            message.setSubject(dto.getSubject());
            message.setText(dto.getMessage());
            message.setFrom(fromAddress);

            mailSender.send(message);
            
            log.info("✅ Email sent successfully to {}", dto.getTo());
            
            // Log the email notification
            NotificationLog notificationLog = new NotificationLog(
                dto.getTo(),
                dto.getMessage(),
                dto.getSubject(),
                NotificationType.EMAIL,
                LocalDateTime.now()
            );

            logRepository.save(notificationLog);

        } catch (Exception e) {
            log.error("❌ Failed to send email to {}", dto.getTo(), e);
            throw new RuntimeException("Email sending failed", e);
        }
    }

    /**
     * Sends an email with HTML content and logs the notification in the database.
     * <p>
     * This method attempts to send an email using the JavaMailSender. It constructs
     * a new {@link MimeMessage}, sets the recipient, subject, and HTML body, and sends it via SMTP.
     * The notification is logged to the database for audit purposes.
     * </p>
     * 
     * @param to the recipient's email address
     * @param subject the subject line for the email
     * @param body the content of the email (HTML is supported)
     * @return {@code true} if the email was sent successfully, {@code false} otherwise
     */
    public boolean sendHtmlEmail(String to, String subject, String body) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, "utf-8");

            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(body, true); // true enables HTML content
            helper.setFrom(fromAddress);

            mailSender.send(message);
            
            log.info("✅ HTML Email sent successfully to {}", to);
            
            // Log the email notification
            NotificationLog notificationLog = new NotificationLog(
                to,
                body,
                subject,
                NotificationType.EMAIL,
                LocalDateTime.now()
            );

            logRepository.save(notificationLog);
            
            return true;
            
        } catch (MessagingException e) {
            log.error("❌ Failed to send HTML email to {}", to, e);
            
            // Still log the failed attempt
            NotificationLog notificationLog = new NotificationLog(
                to,
                body,
                subject,
                NotificationType.EMAIL,
                LocalDateTime.now()
            );

            logRepository.save(notificationLog);
            
            return false;
        }
    }
}