package com.lendrix.notificationservice.enums;

/**
 * Enum to define notification types.
 */
public enum NotificationType {
    EMAIL,
    SMS
}
