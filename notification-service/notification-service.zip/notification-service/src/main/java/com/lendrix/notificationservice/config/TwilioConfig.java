package com.lendrix.notificationservice.config;

import com.twilio.Twilio;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;


/**
 * Configuration class that initializes the Twilio SDK with credentials
 * loaded from the application's properties file.
 * <p>
 * This class reads the Twilio Account SID and Auth Token from the environment
 * (configured via {@code application.properties} or equivalent) and calls
 * {@link com.twilio.Twilio#init(String, String)} to set up the SDK for usage
 * throughout the application.
 * <p>
 * This Spring {@link org.springframework.context.annotation.Configuration}
 * is instantiated at application startup and ensures the Twilio client is ready
 * before any SMS or other Twilio-related services are invoked.
 * <p>
 * <b>Important:</b> The account credentials must be kept secure and should
 * typically not be hardcoded. They should be provided via environment variables,
 * external configuration, or Spring Boot property files.
 * <p>
 * Usage example (in {@code application.properties}):
 * <pre>
 * twilio.account.sid=ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
 * twilio.auth.token=your_auth_token_here
 * </pre>
 */

@Configuration
public class TwilioConfig {

    @Value("${twilio.account.sid}")
    private String accountSid;

    @Value("${twilio.auth.token}")
    private String authToken;

    /**
     * Initializes the Twilio SDK with the provided account SID and auth token.
     * This method is executed once after the bean has been constructed and
     * the properties are injected.
     */
    @PostConstruct
    public void initTwilio() {
        Twilio.init(accountSid, authToken);
    }
}
