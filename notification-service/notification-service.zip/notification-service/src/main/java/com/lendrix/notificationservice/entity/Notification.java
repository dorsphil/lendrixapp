package com.lendrix.notificationservice.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Entity representing a notification (email or SMS) sent to a user.
 * <p>
 * This class captures details about notifications, including recipient information,
 * subject (for emails), message content, type (EMAIL or SMS), sent status, and timestamp.
 * It is mapped to the {@code notifications} table in the database.
 * </p>
 */
@Entity
@Table(name = "notifications")
public class Notification {

    /**
     * Primary key identifier for the notification.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * The recipient's email address or phone number.
     */
    private String recipient;

    /**
     * The subject of the notification (used for emails).
     */
    private String subject;

    /**
     * The main content of the notification.
     */
    @Column(nullable = false)
    private String message;// "EMAIL" or "SMS"

    /**
     * The type of notification, e.g., "EMAIL" or "SMS".
     */
    private String type;

    /**
     * Indicates whether the notification was sent successfully.
     */
    
    private boolean sent;

    /**
     * Timestamp indicating when the notification was created or sent.
     */
    @CreationTimestamp
    private LocalDateTime timestamp;

    /**
     * Default constructor.
     */
    public Notification() {}

    /**
     * Constructs a Notification with the specified details.
     *
     * @param recipient  the recipient's email or phone number
     * @param subject    the subject of the notification (for emails)
     * @param message    the main content of the notification
     * @param type       the type of notification ("EMAIL" or "SMS")
     * @param sent       whether the notification was sent successfully
     * @param timestamp  the time the notification was created or sent
     */
    public Notification(String recipient, String subject, String message, String type, boolean sent, LocalDateTime timestamp) {
        this.recipient = recipient;
        this.subject = subject;
        this.message = message;
        this.type = type;
        this.sent = sent;
        this.timestamp = timestamp;
    }

    /**
     * Returns the notification ID.
     *
     * @return the notification ID
     */
    public Long getId() {
        return id;
    }

    /**
     * Returns the recipient's email or phone number.
     *
     * @return the recipient
     */
    public String getRecipient() {
        return recipient;
    }

    /**
     * Sets the recipient's email or phone number.
     *
     * @param recipient the recipient to set
     */
    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    /**
     * Returns the subject of the notification.
     *
     * @return the subject
     */
    public String getSubject() {
        return subject;
    }

    /**
     * Sets the subject of the notification.
     *
     * @param subject the subject to set
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

    /**
     * Returns the main content of the notification.
     *
     * @return the message content
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the main content of the notification.
     *
     * @param message the message content to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Returns the type of notification ("EMAIL" or "SMS").
     *
     * @return the notification type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type of notification.
     *
     * @param type the notification type to set ("EMAIL" or "SMS")
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Returns whether the notification was sent successfully.
     *
     * @return {@code true} if sent, {@code false} otherwise
     */
    public boolean isSent() {
        return sent;
    }

    /**
     * Sets the sent status of the notification.
     *
     * @param sent {@code true} if sent, {@code false} otherwise
     */
    public void setSent(boolean sent) {
        this.sent = sent;
    }

    /**
     * Returns the timestamp of the notification.
     *
     * @return the timestamp
     */
    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    /**
     * Sets the timestamp of the notification.
     *
     * @param timestamp the timestamp to set
     */
    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
