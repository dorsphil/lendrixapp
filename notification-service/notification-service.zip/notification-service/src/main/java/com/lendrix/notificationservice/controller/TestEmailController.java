package com.lendrix.notificationservice.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lendrix.notificationservice.service.EmailService;

/**
 * Controller for testing email sending via HTTP POST.
 */
@RestController
@RequestMapping("/api/notify")
public class TestEmailController {

    private final EmailService emailService;

    public TestEmailController(EmailService emailService) {
        this.emailService = emailService;
    }

    @PostMapping("/email")
    public String sendEmail(
            @RequestParam String to,
            @RequestParam String subject,
            @RequestParam String message
    ) {
        //boolean result = emailService.sendEmail(to, subject, message);
        // Use the sendHtmlEmail method that returns boolean
        boolean result = emailService.sendHtmlEmail(to, subject, message);
        return result ? "Email sent successfully!" : "Email sending failed.";
    }
}
