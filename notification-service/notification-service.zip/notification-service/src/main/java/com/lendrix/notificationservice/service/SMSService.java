package com.lendrix.notificationservice.service;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.lendrix.notificationservice.dto.NotificationDTO;
import com.lendrix.notificationservice.entity.NotificationLog;
import com.lendrix.notificationservice.enums.NotificationType;
import com.lendrix.notificationservice.repository.NotificationLogRepository;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

/**
 * Service class responsible for sending SMS messages via Twilio.
 * <p>
 * This service uses the Twilio SDK to create and send SMS messages, where the
 * sender's phone number is configured through externalized properties.
 * </p>
 * <p>
 * Example usage:
 * <pre>
 * NotificationDTO dto = new NotificationDTO();
 * dto.setTo("+233501234567");
 * dto.setMessage("Hello from the app!");
 * smsService.sendSms(dto);
 * </pre>
 * </p>
 * 
 * <p>
 * Note: The {@code NotificationDTO} should have the type set to SMS, the recipient's phone 
 * number, and the message content before calling this service.
 * </p>
 * 
 * @see com.lendrix.notificationservice.dto.NotificationDTO
 * @see <a href="https://www.twilio.com/docs/sms">Twilio SMS API Documentation</a>
 */
@Service
public class SMSService {

    private static final Logger log = LoggerFactory.getLogger(SMSService.class);

    @Value("${twilio.phone.from}")
    private String fromNumber;

    private final NotificationLogRepository logRepository;

    //@Autowired
    //private NotificationLogRepository logRepository;

    public SMSService(NotificationLogRepository logRepository) {
        this.logRepository = logRepository;
    }

    /**
     * Sends an SMS message using Twilio.
     *
     * @param dto a {@link NotificationDTO} containing the recipient phone number and message body;
     *            should have type set to SMS
     */
    public void sendSms(NotificationDTO dto) {
        try {
            Message.creator(
                    new PhoneNumber(dto.getTo()),       // to
                    new PhoneNumber(fromNumber),        // from
                    dto.getMessage()                    // message
            ).create();

            log.info("✅ SMS sent successfully to {}", dto.getTo());

            // Log the SMS notification
            NotificationLog notificationLog = new NotificationLog(
                dto.getTo(),
                dto.getMessage(),
                null,
                NotificationType.SMS,
                LocalDateTime.now()
            );

            logRepository.save(notificationLog);

        } catch (Exception e) {
            log.error("❌ Failed to send SMS to {}", dto.getTo(), e);
            throw new RuntimeException("SMS sending failed", e);
        }
    }
}