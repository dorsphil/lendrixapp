
package com.lendrix.notificationservice.dto;

/**
 * Data Transfer Object (DTO) representing a notification message,
 * which can be sent via email or SMS.
 * <p>
 * This class provides a unified structure to encapsulate the details 
 * required for sending notifications through different channels.
 * </p>
 * 
 * <p><b>Fields:</b></p>
 * <ul>
 *   <li><code>type</code>: The type of notification, either "EMAIL" or "SMS".</li>
 *   <li><code>to</code>: The recipient's address, which could be an email or a phone number.</li>
 *   <li><code>subject</code>: The subject of the notification message; only applicable to email notifications and optional for SMS.</li>
 *   <li><code>message</code>: The body content of the notification, for both email and SMS.</li>
 * </ul>
 * 
 * <p><b>Usage Example (JSON representation):</b></p>
 * <pre>
 * {
 *   "type": "EMAIL",
 *   "to": "user@example.com",
 *   "subject": "Lendrix Verification",
 *   "message": "Your code is 1234"
 * }
 * </pre>
 * 
 * <p>This DTO simplifies handling notifications by providing the necessary information
 * for sending both email and SMS using a common object.</p>
 * 
 * @author 
 */
public class NotificationDTO {

    /**
     * The notification type - "EMAIL" or "SMS".
     */
    private String type;

    /**
     * The recipient's email address or phone number.
     */
    private String to;

    /**
     * The subject of the message; only required for email notifications.
     */
    private String subject;

    /**
     * The content/body of the notification message.
     */
    private String message;

    /**
     * Default no-argument constructor.
     */
    public NotificationDTO() {}

    /**
     * Constructs a NotificationDTO with all fields.
     * 
     * @param type the notification type ("EMAIL" or "SMS")
     * @param to the recipient email or phone number
     * @param subject the subject line (optional for SMS)
     * @param message the message body content
     */
    public NotificationDTO(String type, String to, String subject, String message) {
        this.type = type;
        this.to = to;
        this.subject = subject;
        this.message = message;
    }

    /**
     * Returns the notification type.
     * @return the type ("EMAIL" or "SMS")
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the notification type.
     * @param type the type to set ("EMAIL" or "SMS")
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Returns the recipient's contact information.
     * @return the recipient email or phone number
     */
    public String getTo() {
        return to;
    }

    /**
     * Sets the recipient's contact information.
     * @param to the recipient email or phone number
     */
    public void setTo(String to) {
        this.to = to;
    }

    /**
     * Returns the subject of the notification.
     * @return the subject (only for email)
     */
    public String getSubject() {
        return subject;
    }

    /**
     * Sets the subject of the notification.
     * @param subject the subject to set (only for email)
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

    /**
     * Returns the content of the notification message.
     * @return the message body
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the content of the notification message.
     * @param message the message body to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
}

