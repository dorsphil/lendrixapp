# Notification Setup Documentation

Handles sending emails and SMS notifications for user actions like login, registration, and alerts.


## Project Structure
notification-service/
- ├── src/
- │   └── main/
- │       ├── java/com/lendrix/notification-service/
- │       │   ├── controller/
- │       │   ├── dto/
- |       |   ├── model/
- │       │   ├── repository/
- │       │   ├── service/
- │       │   └── AuthServiceApplication.java
- ├── application.properties

## Step 1: Initialize Spring Boot Project

**Microservice name**:  notification-service

- Tool: Spring CLI
- Command used:
```
    bash
        spring init notification-service --build=maven --dependencies=web,data-jpa,mail,postgresql --java-version=17 --packaging=jar --type=maven-project --groupId=com.lendrix --artifactId=notification-service --name=notification-service
```

- **Dependencies**:
  - Spring Web  -To expose REST APIs
  - Spring Boot DevTools
  - Spring Security -For authentication and authorization
  - Spring Data JPA -ORM to interact with PostgreSQL
  - PostgreSQL Driver -Connects the service to a PostgreSQL database

*Moved to folder:*
```
    /Documents/lendrix-backend/notification-service
```

## Step 2: Basic Configuration
- Port: 8081
- DB: PostgreSQL (notificationdb)
- SMTP: Gmail SMTP setup

location: /src/main/resources/application.properties
```
# ========== SERVER CONFIG ==========
server.port=8081
spring.application.name=notification-service

# ========== DATABASE CONFIG ==========
spring.datasource.url=jdbc:postgresql://localhost:5432/notificationdb
spring.datasource.username=dorsphil
spring.datasource.password=dorsphil123
spring.datasource.driver-class-name=org.postgresql.Driver
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.PostgreSQLDialect
```
##  Step 3: Connect to PostgreSQL and Create the Notification Entity
  A. Create Entity: Notification.java
  location: src/main/java/com/lendrix/notificationservice/model/Notification.java
```
    package com.lendrix.notificationservice.model;

    import jakarta.persistence.*;
    import java.time.LocalDateTime;

    /**
    * Represents a notification (email or SMS) sent to a user.
    */
    @Entity
    @Table(name = "notifications")
    public class Notification {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        private String recipient;  // Email or phone number
        private String subject;    // For email
        private String message;    // Main content
        private String type;       // "EMAIL" or "SMS"
        private boolean sent;

        private LocalDateTime timestamp;

        // Constructors
        public Notification() {}

        public Notification(String recipient, String subject, String message, String type, boolean sent, LocalDateTime timestamp) {
            this.recipient = recipient;
            this.subject = subject;
            this.message = message;
            this.type = type;
            this.sent = sent;
            this.timestamp = timestamp;
        }

        // Getters and setters
        // (You can use Lombok if preferred later)
        public Long getId() {
            return id;
        }

        public String getRecipient() {
            return recipient;
        }

        public void setRecipient(String recipient) {
            this.recipient = recipient;
        }

        public String getSubject() {
            return subject;
        }

        public void setSubject(String subject) {
            this.subject = subject;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public boolean isSent() {
            return sent;
        }

        public void setSent(boolean sent) {
            this.sent = sent;
        }

        public LocalDateTime getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
        }
    }
```
## Step 4:  Create Repository
location: repository/NotificationRepository.java
```
  package com.lendrix.notificationservice.repository;

  import com.lendrix.notificationservice.model.Notification;
  import org.springframework.data.jpa.repository.JpaRepository;

  public interface NotificationRepository extends JpaRepository<Notification, Long> {
      // You can add custom findByRecipient, etc. later if needed
  }
```

## Step 5: Create the Service Class
src/main/java/com/lendrix/notificationservice/service/EmailService.java
```
    package com.lendrix.notificationservice.service;

        import com.lendrix.notificationservice.model.Notification;
        import com.lendrix.notificationservice.repository.NotificationRepository;
        import jakarta.mail.MessagingException;
        import jakarta.mail.internet.MimeMessage;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.mail.javamail.JavaMailSender;
        import org.springframework.mail.javamail.MimeMessageHelper;
        import org.springframework.stereotype.Service;

        import java.time.LocalDateTime;

        /**
        * Service responsible for sending emails via SMTP.
        */
        @Service
        public class EmailService {

            @Autowired
            private JavaMailSender mailSender;

            @Autowired
            private NotificationRepository notificationRepository;

            /**
            * Sends an email and logs the notification in the database.
            * @param to Recipient email address
            * @param subject Email subject
            * @param body Email message
            * @return true if sent successfully, false otherwise
            */
            public boolean sendEmail(String to, String subject, String body) {
                boolean success = false;

                try {
                    MimeMessage message = mailSender.createMimeMessage();
                    MimeMessageHelper helper = new MimeMessageHelper(message, "utf-8");

                    helper.setTo(to);
                    helper.setSubject(subject);
                    helper.setText(body, true); // true enables HTML content
                    helper.setFrom("lendrixapp@gmail.com");

                    mailSender.send(message);
                    success = true;
                } catch (MessagingException e) {
                    e.printStackTrace();
                }

                // Save to DB
                Notification notification = new Notification();
                notification.setRecipient(to);
                notification.setSubject(subject);
                notification.setMessage(body);
                notification.setType("EMAIL");
                notification.setSent(success);
                notification.setTimestamp(LocalDateTime.now());

                notificationRepository.save(notification);

                return success;
            }
        }
```

## Step 6: Add JavaMailSender Bean
src/main/java/com/lendrix/notificationservice/config/MailConfig.java
```
    package com.lendrix.notificationservice.config;

        import org.springframework.context.annotation.Bean;
        import org.springframework.context.annotation.Configuration;
        import org.springframework.mail.javamail.JavaMailSender;
        import org.springframework.mail.javamail.JavaMailSenderImpl;

        import java.util.Properties;

        /**
        * Configuration for JavaMailSender with Gmail SMTP.
        */
        @Configuration
        public class MailConfig {

            @Bean
            public JavaMailSender mailSender() {
                JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
                mailSender.setHost("smtp.gmail.com");
                mailSender.setPort(587);

                mailSender.setUsername("lendrixapp@gmail.com");
                mailSender.setPassword("your_app_password_here");

                Properties props = mailSender.getJavaMailProperties();
                props.put("mail.transport.protocol", "smtp");
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.starttls.required", "true");
                props.put("mail.debug", "true");

                return mailSender;
            }
        }
```
## Step 7: Add to application.properties
src/main/resources/application.properties
```
    spring.mail.protocol=smtp
```

## Step 8: Add Controller for Testing (Temporary)
controller/TestEmailController.java
```
    package com.lendrix.notificationservice.controller;

        import com.lendrix.notificationservice.service.EmailService;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.web.bind.annotation.*;

        /**
        * Controller for testing email sending via HTTP POST.
        */
        @RestController
        @RequestMapping("/api/notify")
        public class TestEmailController {

            @Autowired
            private EmailService emailService;

            @PostMapping("/email")
            public String sendEmail(
                    @RequestParam String to,
                    @RequestParam String subject,
                    @RequestParam String message
            ) {
                boolean result = emailService.sendEmail(to, subject, message);
                return result ? "Email sent successfully!" : "Email sending failed.";
            }
        }
```

## Test via Postman
-- POST http://localhost:8081/api/notify/email

Params:
- to: your email address
- subject: test subject
- message: test body

##  Create NotificationDTO and generalize sending for both email/SMS
notificationservice/src/main/java/com/lendrix/notificationservice/dto/NotificationDTO.java
```
    package com.lendrix.notificationservice.dto;

        public class NotificationDTO {

        private String type; // "EMAIL" or "SMS"
        private String to;
        private String subject; // optional for SMS
        private String message;

        // Constructors
        public NotificationDTO() {}

        public NotificationDTO(String type, String to, String subject, String message) {
            this.type = type;
            this.to = to;
            this.subject = subject;
            this.message = message;
        }

        // Getters and Setters
        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getTo() {
            return to;
        }

        public void setTo(String to) {
            this.to = to;
        }

        public String getSubject() {
            return subject;
        }

        public void setSubject(String subject) {
            this.subject = subject;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
```

## Update EmailService.java to accept NotificationDTO
```
    import com.lendrix.notificationservice.dto.NotificationDTO;

// ...

    public void sendEmail(NotificationDTO dto) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(dto.getTo());
            message.setSubject(dto.getSubject());
            message.setText(dto.getMessage());
            message.setFrom(fromAddress);

            mailSender.send(message);
            log.info("✅ Email sent to {}", dto.getTo());

        } catch (Exception e) {
            log.error("❌ Failed to send email to {}", dto.getTo(), e);
            throw new RuntimeException("Email sending failed", e);
        }
    }
```

## Twilio Setup & Spring Boot Integration for Lendrix Notification Service

1. Create a Twilio Account(free trial)
2. Get credentials; AccountSID, Auth Token
3. Buy a number for use(US number, cheaper otion)

    # A. Add Twilio to the Spring Boot Project in pom.xml
```
    <dependency>
        <groupId>com.twilio.sdk</groupId>
        <artifactId>twilio</artifactId>
        <version>9.18.1</version>
    </dependency>
```
# B. Add Twilio Config to application.properties
```
    # Twilio configuration
    twilio.account.sid=your_twilio_account_sid_here
    twilio.auth.token=your_twilio_auth_token_here
    twilio.phone.from=your_twilio_trial_number_here
```
# C. Create TwilioConfig.java
notification-service/src/main/java/com/lendrix/notificationservice/config/TwilioConfig.java
```
    package com.lendrix.notificationservice.config;

        import com.twilio.Twilio;
        import jakarta.annotation.PostConstruct;
        import org.springframework.beans.factory.annotation.Value;
        import org.springframework.context.annotation.Configuration;

        /**
        * Initializes the Twilio SDK on application startup with credentials
        * from application.properties
        */
        @Configuration
        public class TwilioConfig {

            @Value("${twilio.account.sid}")
            private String accountSid;

            @Value("${twilio.auth.token}")
            private String authToken;

            @PostConstruct
            public void initTwilio() {
                Twilio.init(accountSid, authToken);
            }
        }
```
# D. Create SMSService.java
notification-service/src/main/java/com/lendrix/notificationservice/service/SMSService.java
```
    package com.lendrix.notificationservice.service;

        import com.lendrix.notificationservice.dto.NotificationDTO;
        import com.twilio.rest.api.v2010.account.Message;
        import com.twilio.type.PhoneNumber;
        import org.springframework.beans.factory.annotation.Value;
        import org.springframework.stereotype.Service;

        /**
        * Service for sending SMS using Twilio
        */
        @Service
        public class SMSService {

            @Value("${twilio.phone.from}")
            private String fromNumber;

            /**
            * Sends an SMS using Twilio
            * 
            * @param dto the NotificationDTO with type=SMS, to=recipient phone, message=body
            */
            public void sendSms(NotificationDTO dto) {
                Message.creator(
                        new PhoneNumber(dto.getTo()),       // to
                        new PhoneNumber(fromNumber),        // from
                        dto.getMessage()                    // message
                ).create();
            }
        }
```
# E. Update Controller to Handle Both Email and SMS
notification-service/src/main/java/com/lendrix/notificationservice/controller/NotificationController.java
```
    package com.lendrix.notificationservice.controller;

        import com.lendrix.notificationservice.dto.NotificationDTO;
        import com.lendrix.notificationservice.service.EmailService;
        import com.lendrix.notificationservice.service.SMSService;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.web.bind.annotation.*;

        /**
        * Controller for sending notifications via email or SMS.
        */
        @RestController
        @RequestMapping("/api/notify")
        public class NotificationController {

            @Autowired
            private EmailService emailService;

            @Autowired
            private SMSService smsService;

            @PostMapping
            public String sendNotification(@RequestBody NotificationDTO dto) {
                switch (dto.getType().toUpperCase()) {
                    case "EMAIL" -> {
                        emailService.sendEmail(dto);
                        return "✅ Email sent";
                    }
                    case "SMS" -> {
                        smsService.sendSms(dto);
                        return "✅ SMS sent";
                    }
                    default -> throw new IllegalArgumentException("❌ Unsupported type: " + dto.getType());
                }
            }
        }
```
# Test With Postman
* Email Test
POST http://localhost:8081/api/notify
Body (raw → JSON):
```
 {
    "type": "EMAIL",
    "to": "your@email.com",
    "subject": "Lendrix Alert",
    "message": "This is a test email from notification service"
 }
 ```
* SMS Test
POST http://localhost:8081/api/notify
Body (raw → JSON):
```
    {
        "type": "SMS",
        "to": "+233xxxxxxxxx",
        "message": "Your Lendrix code is 1234"
    }
```


## Logging Sent Notifications

1. Create the NotificationLog entity
notification-service/src/main/java/com/lendrix/notificationservice/entity/NotificationLog.java
```
    package com.lendrix.notificationservice.entity;

        import com.lendrix.notificationservice.enums.NotificationType;
        import jakarta.persistence.*;
        import java.time.LocalDateTime;

        /**
        * Entity to store logs of all notifications sent (Email or SMS).
        */
        @Entity
        @Table(name = "notification_logs")
        public class NotificationLog {

            @Id
            @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;

            private String recipient;

            private String message;

            private String subject; // for email

            @Enumerated(EnumType.STRING)
            private NotificationType type;

            private LocalDateTime sentAt;

            // Constructors
            public NotificationLog() {}

            public NotificationLog(String recipient, String message, String subject, NotificationType type, LocalDateTime sentAt) {
                this.recipient = recipient;
                this.message = message;
                this.subject = subject;
                this.type = type;
                this.sentAt = sentAt;
            }

            // Getters and Setters
            public Long getId() { return id; }
            public String getRecipient() { return recipient; }
            public void setRecipient(String recipient) { this.recipient = recipient; }
            public String getMessage() { return message; }
            public void setMessage(String message) { this.message = message; }
            public String getSubject() { return subject; }
            public void setSubject(String subject) { this.subject = subject; }
            public NotificationType getType() { return type; }
            public void setType(NotificationType type) { this.type = type; }
            public LocalDateTime getSentAt() { return sentAt; }
            public void setSentAt(LocalDateTime sentAt) { this.sentAt = sentAt; }
        }
```

2. Create the NotificationLogRepository
notification-service/src/main/java/com/lendrix/notificationservice/repository/NotificationLogRepository.java
```
    package com.lendrix.notificationservice.repository;

        import com.lendrix.notificationservice.entity.NotificationLog;
        import org.springframework.data.jpa.repository.JpaRepository;

        /**
        * Repository for managing NotificationLog entries.
        */
        public interface NotificationLogRepository extends JpaRepository<NotificationLog, Long> {
        }
```
3.  Update EmailService to log after sending
```
    private final NotificationLogRepository logRepository;

    public EmailService(JavaMailSender mailSender, NotificationLogRepository logRepository) {
        this.mailSender = mailSender;
        this.logRepository = logRepository;
    }
```
```
    NotificationLog log = new NotificationLog(
        emailRequest.getTo(),
        emailRequest.getMessage(),
        emailRequest.getSubject(),
        NotificationType.EMAIL,
        LocalDateTime.now()
    );
    logRepository.save(log);
```

4. Update SMSService to log after sending
```
    private final NotificationLogRepository logRepository;

    public SMSService(NotificationLogRepository logRepository) {
        this.logRepository = logRepository;
    }
```
## Error Handling + Fallback in notification-service
1.  Add Custom Exception Class
src/main/java/com/lendrix/notificationservice/exception/NotificationException.java
```
    package com.lendrix.notificationservice.exception;

    /**
    * Custom exception for notification-related errors (email or SMS).
    */
    public class NotificationException extends RuntimeException {

        public NotificationException(String message) {
            super(message);
        }

        public NotificationException(String message, Throwable cause) {
            super(message, cause);
        }
    }
```
2.  Handle Email Errors Gracefully(EmailService.java)
* Wrap the sendEmail() method in a try-catch

3. Handle SMS Errors with Fallback Simulation

4. Add Logging Configuration in application.properties
```
    logging.level.com.lendrix.notificationservice=DEBUG
```

































