package com.lendrix.authservice.controller;

import com.lendrix.authservice.dto.AccountTypeRequest;
import com.lendrix.authservice.dto.AuthRequest;
import com.lendrix.authservice.dto.AuthResponse;
import com.lendrix.authservice.dto.CountrySelectionRequest;
import com.lendrix.authservice.dto.EmailRegistrationRequest;
import com.lendrix.authservice.dto.GoogleSignInRequest;
import com.lendrix.authservice.dto.LoginRequest;
import com.lendrix.authservice.dto.LoginResponse;
import com.lendrix.authservice.dto.PasswordRequest;
import com.lendrix.authservice.dto.PhoneCodeVerificationRequest;
import com.lendrix.authservice.dto.PhoneVerificationRequest;
import com.lendrix.authservice.dto.RegistrationPasscodeRequest;
import com.lendrix.authservice.dto.FirebaseLoginRequest;
import com.lendrix.authservice.dto.ForgotPasswordRequest;
import com.lendrix.authservice.model.User;
import com.lendrix.authservice.model.VerificationToken;
import com.lendrix.authservice.repository.UserRepository;
import com.lendrix.authservice.repository.VerificationTokenRepository;
import com.lendrix.authservice.service.AuthService;
import com.lendrix.authservice.service.PhoneVerificationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * REST controller for handling multi-step authentication registration.
 * 
 * Registration Flow:
 * 1. POST /api/auth/register/start - Enter email and full name
 * 2. GET /api/auth/verify-email?token=... - Verify email
 * 3. POST /api/auth/register/account-type - Choose account type
 * 4. POST /api/auth/register/country - Choose country of residence
 * 5. POST /api/auth/register/phone/initiate - Start phone verification
 * 6. POST /api/auth/register/phone/verify - Verify phone code
 * 7. POST /api/auth/register/finalize - Set password and complete registration
 * 
 * @author Dorsphil Osei <dorsphillloseiasuming@gmail.com>
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @Autowired
    private VerificationTokenRepository tokenRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PhoneVerificationService phoneVerificationService;

    // ============= LEGACY SINGLE-STEP REGISTRATION (Keep for backward compatibility) =============
    
    /**
     * Legacy single-step registration endpoint.
     * @deprecated Use the multi-step registration flow instead
     */
    @PostMapping("/register")
    @Deprecated
    public AuthResponse register(@RequestBody AuthRequest request) {
        return authService.register(request);
    }

    /**
     * Login endpoint
     */
    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        return authService.login(request);
}


    // ============= MULTI-STEP REGISTRATION FLOW =============

    /**
     * STEP 1: Start registration with email and full name
     * Creates a user record and sends email verification
     */
    @PostMapping("/register/start")
    public ResponseEntity<AuthResponse> startRegistration(@RequestBody EmailRegistrationRequest request) {
        try {
            AuthResponse response = authService.startRegistration(request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(new AuthResponse(e.getMessage()));
        }
    }

    /**
     * STEP 2: Verify email address
     * Validates the email verification token
     */
    @GetMapping("/verify-email")
    public ResponseEntity<String> verifyEmail(@RequestParam("token") String token) {
        Optional<VerificationToken> optional = tokenRepository.findByToken(token);

        if (optional.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid token.");
        }

        VerificationToken verificationToken = optional.get();

        if (verificationToken.getExpiryDate().isBefore(LocalDateTime.now())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Token expired.");
        }

        User user = verificationToken.getUser();
        user.setEmailVerified(true);
        userRepository.save(user);

        // Clean up the used token
        tokenRepository.delete(verificationToken);

        return ResponseEntity.ok("Email verified successfully. You can now continue with account setup.");
    }

    /**
     * STEP 3: Select account type (Personal or Business)
     * Requires email to be verified
     */
    @PostMapping("/register/account-type")
    public ResponseEntity<AuthResponse> saveAccountType(@RequestBody AccountTypeRequest request) {
        try {
            AuthResponse response = authService.saveAccountType(request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(new AuthResponse(e.getMessage()));
        }
    }

    /**
     * STEP 4: Select country of residence
     * Requires email verification and account type selection
     */
    @PostMapping("/register/country")
    public ResponseEntity<AuthResponse> saveCountryOfResidence(@RequestBody CountrySelectionRequest request) {
        try {
            AuthResponse response = authService.saveCountryOfResidence(request);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(new AuthResponse(e.getMessage()));
        }
    }

    /**
     * STEP 5: Initiate phone number verification
     * Requires email verification, account type, and country selection
     */
    @PostMapping("/register/phone/initiate")
    public ResponseEntity<String> initiatePhoneVerification(@RequestBody PhoneVerificationRequest request) {
        try {
            // Validate prerequisite steps
            authService.validatePhoneVerificationPrerequisites(request.getEmail());
            
            phoneVerificationService.initiateVerification(request.getEmail(), request.getPhoneNumber());
            return ResponseEntity.ok("Verification code sent to your phone number.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    /**
     * STEP 6: Verify phone number code
     * Validates the SMS code sent to user's phone
     */
    @PostMapping("/register/phone/verify")
    public ResponseEntity<String> verifyPhoneCode(@RequestBody PhoneCodeVerificationRequest request) {
        try {
            boolean success = phoneVerificationService.verifyCode(request.getEmail(), request.getCode());
            return success ?
                ResponseEntity.ok("Phone number verified successfully.") :
                ResponseEntity.badRequest().body("Invalid or expired verification code.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    /**
     * STEP 7: Finalize registration with password
     * Completes the registration process
     */
    @PostMapping("/register/finalize")
    public ResponseEntity<String> finalizeRegistration(@RequestBody PasswordRequest request) {
        try {
            authService.finalizeRegistration(request.getEmail(), request.getPassword());
            return ResponseEntity.ok("Registration completed successfully. You can now login.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // ============= UTILITY ENDPOINTS =============

    /**
     * Check registration status for a given email
     */
    @GetMapping("/register/status")
    public ResponseEntity<AuthResponse> getRegistrationStatus(@RequestParam("email") String email) {
        try {
            AuthResponse response = authService.getRegistrationStatus(email);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(new AuthResponse(e.getMessage()));
        }
    }

    /**
     * Resend email verification token
     */
    @PostMapping("/register/resend-email")
    public ResponseEntity<String> resendEmailVerification(@RequestParam("email") String email) {
        try {
            authService.resendEmailVerification(email);
            return ResponseEntity.ok("Verification email sent.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/register/passcode")
    public ResponseEntity<String> savePasscode(@RequestBody RegistrationPasscodeRequest request) {
        return authService.savePasscode(request);
    }

    @PostMapping("/google-signin")
        public ResponseEntity<?> googleSignIn(@RequestBody GoogleSignInRequest request) {
            return authService.googleSignIn(request);
        }

        // Firebase login
        @PostMapping("/firebase-login")
        public ResponseEntity<?> firebaseLogin(@RequestBody FirebaseLoginRequest request) {
            return authService.firebaseLogin(request);
        }

        // Password reset
        @PostMapping("/forgot-password")
        public ResponseEntity<?> resetPassword(@RequestBody ForgotPasswordRequest request) {
            return authService.resetPasswordWithPasscode(request);
        }


}