package com.lendrix.authservice.dto;

/**
 * Data Transfer Object (DTO) for authentication responses.
 * <p>
 * This class encapsulates the response message returned after an authentication operation,
 * such as login or registration.
 * It is used to transfer response data from the server to the client,
 * typically in REST API responses.
 * </p>
 * 
 * <p><b>Fields:</b></p>
 * <ul>
 *   <li><b>message</b> - A textual message indicating the result of the authentication request,
 *   such as success or error information.</li>
 * </ul>
 * 
 * <p>This class provides constructors for easy instantiation, as well as standard getters and setters.</p>
 * 
 * @author  Dorsphil Osei
 *          dorsphillloseiasuming@gmail.com
 * 
 * @version 1.0
 */

public class AuthResponse {

    /**
     * The response message indicating the outcome of an authentication request.
     */
    private String message;

    /**
     * Default no-argument constructor.
     */
    public AuthResponse() {}

    /**
     * Constructs an AuthResponse with the specified message.
     * 
     * @param message the response message
     */
    public AuthResponse(String message) {
        this.message = message;
    }

    /**
     * Returns the response message.
     * 
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the response message.
     * 
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
