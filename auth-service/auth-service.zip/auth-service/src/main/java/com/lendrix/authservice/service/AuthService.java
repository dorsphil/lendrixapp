package com.lendrix.authservice.service;

import com.lendrix.authservice.dto.AccountTypeRequest;
import com.lendrix.authservice.dto.AuthRequest;
import com.lendrix.authservice.dto.AuthResponse;
import com.lendrix.authservice.dto.CountrySelectionRequest;
import com.lendrix.authservice.dto.EmailRegistrationRequest;
import com.lendrix.authservice.dto.FirebaseLoginRequest;
import com.lendrix.authservice.dto.ForgotPasswordRequest;
import com.lendrix.authservice.dto.GoogleSignInRequest;
import com.lendrix.authservice.dto.LoginRequest;
import com.lendrix.authservice.dto.LoginResponse;
import com.lendrix.authservice.dto.RegistrationPasscodeRequest;
import com.lendrix.authservice.model.User;
import com.lendrix.authservice.model.VerificationToken;
import com.lendrix.authservice.repository.UserRepository;
import com.lendrix.authservice.repository.VerificationTokenRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;
import java.util.Optional;
import java.util.Collections;
import java.util.Map;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken.Payload;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;

// deprecated: import com.google.api.client.json.jackson2.JacksonFactory;

import com.google.api.client.json.gson.GsonFactory; // Changed from JacksonFactory
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseToken;


/**
 * Enhanced AuthService with proper multi-step registration flow
 * 
 * Registration Steps:
 * 1. Start registration (email + full name)
 * 2. Email verification
 * 3. Account type selection
 * 4. Country selection  
 * 5. Phone verification initiation
 * 6. Phone verification confirmation
 * 7. Password creation and finalization
 * 
 * @author Dorsphil Osei <dorsphillloseiasuming@gmail.com>
 */
@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private VerificationTokenRepository tokenRepository;

    @Autowired
    private EmailService emailService;

    private final PasswordEncoder passwordEncoder;

    public AuthService(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

    // ============= LEGACY SINGLE-STEP REGISTRATION =============
    
    /**
     * Legacy single-step registration
     * @deprecated Use startRegistration() for multi-step flow
     */
    @Deprecated
    public AuthResponse register(AuthRequest request) {
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            return new AuthResponse("User already exists");
        }

        User user = new User();
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setFullName(request.getFullName());
        user.setEmailVerified(false);

        String token = UUID.randomUUID().toString();
        VerificationToken verificationToken = new VerificationToken();
        verificationToken.setToken(token);
        verificationToken.setUser(user);
        verificationToken.setExpiryDate(LocalDateTime.now().plusMinutes(10));
        tokenRepository.save(verificationToken);

        emailService.sendVerificationEmail(user, token);
        
        return new AuthResponse("Registration successful. Please check your email to verify your account.");
    }


    // ============= MULTI-STEP REGISTRATION FLOW =============

    /**
     * STEP 1: Start registration with email and full name
     * Creates incomplete user record and sends email verification
     */
    public AuthResponse startRegistration(EmailRegistrationRequest request) {
        // Check if user already exists
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("An account with this email already exists");
        }

        // Create new user with minimal information
        User user = new User();
        user.setEmail(request.getEmail());
        user.setFullName(request.getFullName());
        user.setEmailVerified(false);
        user.setPhoneVerified(false);
        
        // Set temporary password - will be replaced in finalizeRegistration
        user.setPassword("TEMP_PASSWORD_TO_BE_SET");
        
        
        userRepository.save(user);

        // Generate and save verification token
        String token = UUID.randomUUID().toString();
        VerificationToken verificationToken = new VerificationToken();
        verificationToken.setToken(token);
        verificationToken.setUser(user);
        verificationToken.setExpiryDate(LocalDateTime.now().plusMinutes(15)); // 15 minutes for email verification
        tokenRepository.save(verificationToken);

        // Send verification email
        emailService.sendVerificationEmail(user, token);

        return new AuthResponse("Registration started successfully. Please check your email to verify your account.");
    }

    /**
     * STEP 3: Save account type (Personal or Business)
     * Requires email to be verified first
     */
    public AuthResponse saveAccountType(AccountTypeRequest request) {
        Optional<User> optionalUser = userRepository.findByEmail(request.getEmail());
        
        if (optionalUser.isEmpty()) {
            throw new RuntimeException("User not found. Please start registration first.");
        }

        User user = optionalUser.get();
        
        // Validate prerequisites
        if (!user.isEmailVerified()) {
            throw new RuntimeException("Please verify your email address first.");
        }

        // Validate account type
        String accountType = request.getAccountType();
        if (!"Personal".equalsIgnoreCase(accountType) && !"Business".equalsIgnoreCase(accountType)) {
            throw new RuntimeException("Account type must be either 'Personal' or 'Business'.");
        }

        user.setAccountType(accountType);
        userRepository.save(user);

        return new AuthResponse("Account type saved successfully.");
    }

    /**
     * STEP 4: Save country of residence
     * Requires email verification and account type selection
     */
    public AuthResponse saveCountryOfResidence(CountrySelectionRequest request) {
        Optional<User> optionalUser = userRepository.findByEmail(request.getEmail());
        
        if (optionalUser.isEmpty()) {
            throw new RuntimeException("User not found. Please start registration first.");
        }

        User user = optionalUser.get();
        
        // Validate prerequisites
        if (!user.isEmailVerified()) {
            throw new RuntimeException("Please verify your email address first.");
        }
        
        if (user.getAccountType() == null || user.getAccountType().trim().isEmpty()) {
            throw new RuntimeException("Please select an account type first.");
        }

        user.setCountryOfResidence(request.getCountry());
        userRepository.save(user);

        return new AuthResponse("Country of residence saved successfully.");
    }

    /**
     * Validate prerequisites for phone verification step
     */
    public void validatePhoneVerificationPrerequisites(String email) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        
        if (optionalUser.isEmpty()) {
            throw new RuntimeException("User not found. Please start registration first.");
        }

        User user = optionalUser.get();
        
        if (!user.isEmailVerified()) {
            throw new RuntimeException("Please verify your email address first.");
        }
        
        if (user.getAccountType() == null || user.getAccountType().trim().isEmpty()) {
            throw new RuntimeException("Please select an account type first.");
        }
        
        if (user.getCountryOfResidence() == null || user.getCountryOfResidence().trim().isEmpty()) {
            throw new RuntimeException("Please select your country of residence first.");
        }
    }

    /**
     * STEP 7: Finalize registration with password
     * Completes the entire registration process
     */
    public void finalizeRegistration(String email, String password) {
        Optional<User> optionalUser = userRepository.findByEmail(email);

        if (optionalUser.isEmpty()) {
            throw new RuntimeException("User not found. Please start registration first.");
        }

        User user = optionalUser.get();

        // Validate all prerequisites are completed
        if (!user.isEmailVerified()) {
            throw new RuntimeException("Please verify your email address first.");
        }
        
        if (user.getAccountType() == null || user.getAccountType().trim().isEmpty()) {
            throw new RuntimeException("Please select an account type first.");
        }
        
        if (user.getCountryOfResidence() == null || user.getCountryOfResidence().trim().isEmpty()) {
            throw new RuntimeException("Please select your country of residence first.");
        }

        if (!user.isPhoneVerified()) {
            throw new RuntimeException("Please verify your phone number first.");
        }

        // Validate password strength (basic validation)
        if (password == null || password.length() < 8) {
            throw new RuntimeException("Password must be at least 8 characters long.");
        }

        // Set encrypted password
        user.setPassword(passwordEncoder.encode(password));
        userRepository.save(user);
    }

    // ============= UTILITY METHODS =============

    /**
     * Get current registration status for a user
     */
    public AuthResponse getRegistrationStatus(String email) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        
        if (optionalUser.isEmpty()) {
            throw new RuntimeException("User not found.");
        }

        User user = optionalUser.get();
        StringBuilder status = new StringBuilder("Registration Progress: ");
        
        if (!user.isEmailVerified()) {
            status.append("Email verification pending");
        } else if (user.getAccountType() == null) {
            status.append("Account type selection pending");
        } else if (user.getCountryOfResidence() == null) {
            status.append("Country selection pending");
        } else if (!user.isPhoneVerified()) {
            status.append("Phone verification pending");
        } else if (user.getPassword() == null) {
            status.append("Password creation pending");
        } else {
            status.append("Registration complete");
        }

        return new AuthResponse(status.toString());
    }

    /**
     * Resend email verification token
     */
    public void resendEmailVerification(String email) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        
        if (optionalUser.isEmpty()) {
            throw new RuntimeException("User not found.");
        }

        User user = optionalUser.get();
        
        if (user.isEmailVerified()) {
            throw new RuntimeException("Email is already verified.");
        }

        // Delete any existing tokens for this user
        tokenRepository.findByToken(user.getEmail()).ifPresent(tokenRepository::delete);

        // Generate new token
        String token = UUID.randomUUID().toString();
        VerificationToken verificationToken = new VerificationToken();
        verificationToken.setToken(token);
        verificationToken.setUser(user);
        verificationToken.setExpiryDate(LocalDateTime.now().plusMinutes(15));
        tokenRepository.save(verificationToken);

        // Send verification email
        emailService.sendVerificationEmail(user, token);
    }

    /**
     * Saves a 4-digit passcode for user registration after validation.
     * <p>
     * This method performs the following operations:
     * <ul>
     *   <li>Retrieves the user by email address from the repository</li>
     *   <li>Validates that the passcode is a 4-digit numeric string</li>
     *   <li>Saves the validated passcode to the user entity</li>
     *   <li>Persists the updated user entity</li>
     * </ul>
     * </p>
     * <p>
     * <strong>Validation Rules:</strong>
     * The passcode must be exactly 4 digits (0-9). Any other format will be rejected.
     * </p>
     *
     * @param request the {@link RegistrationPasscodeRequest} containing the user's email and passcode
     * @return a {@link ResponseEntity} with:
     *         <ul>
     *           <li>HTTP 200 OK and success message if passcode is saved</li>
     *           <li>HTTP 400 Bad Request with error message if:
     *               <ul>
     *                 <li>User is not found</li>
     *                 <li>Passcode is not a 4-digit number</li>
     *               </ul>
     *           </li>
     *         </ul>
     */
    public ResponseEntity<String> savePasscode(RegistrationPasscodeRequest request) {
        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());

        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("User not found");
        }

        User user = userOpt.get();

        String passcode = request.getPasscode();

        if (passcode == null || !passcode.matches("\\d{4}")) {
            return ResponseEntity.badRequest().body("Passcode must be a 4-digit number.");
        }

        user.setPasscode(passcode);
        userRepository.save(user);

        return ResponseEntity.ok("Passcode saved successfully.");
    }

    //========================
    //      LOGIN
    //========================
    /**
     * Verifies email and password during login.
     *
     * @param request LoginRequest containing email and password.
     * @return ResponseEntity with a message about 2FA or failure.
     */
    public ResponseEntity<LoginResponse> login(LoginRequest request) {
        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());
        
        if (userOpt.isEmpty()) {
            return ResponseEntity
                .status(HttpStatus.UNAUTHORIZED)
                .body(new LoginResponse("Invalid credentials"));
        }

        User user = userOpt.get();

        // Check if email is verified
        if (!user.isEmailVerified()) {
            return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(new LoginResponse("Email not verified. Please verify your email."));
        }

        // Check password
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            return ResponseEntity
                .status(HttpStatus.UNAUTHORIZED)
                .body(new LoginResponse("Invalid credentials"));
        }

        // Otherwise simulate 2FA required (next step)
        return ResponseEntity.ok(new LoginResponse(
        "Login successful.Notification sent to your trusted device."));
    }

    //=========================
    //      GOOGLE LOGIN
    //=========================

    public ResponseEntity<?> googleSignIn(GoogleSignInRequest request) {
        try {
            GsonFactory jsonFactory = GsonFactory.getDefaultInstance(); // Changed from JacksonFactory
            GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(
                    GoogleNetHttpTransport.newTrustedTransport(), 
                    jsonFactory)
                   .setAudience(Collections.singletonList("22225975817-3rcfe0elct39o9ku4hrkprt1lg0uqc7d.apps.googleusercontent.com"))
                    .build();
                    
            GoogleIdToken idToken = verifier.verify(request.getIdToken());
            
            if (idToken != null) {
                Payload payload = idToken.getPayload();
                String email = payload.getEmail();
                String fullName = (String) payload.get("name");
                
                Optional<User> userOpt = userRepository.findByEmail(email);
                User user;
                
                if (userOpt.isPresent()) {
                    user = userOpt.get();
                } else {
                    // New user, create one with default values
                    user = new User();
                    user.setEmail(email);
                    user.setFullName(fullName);
                    user.setEmailVerified(true); // Assume Google email is verified
                    user.setPassword(null); // No password needed for Google login
                    userRepository.save(user);
                }
                
                // Simulate JWT creation
                String fakeJwt = "jwt_token_for_" + user.getEmail();
                
                return ResponseEntity.ok(Map.of(
                        "message", "Login successful via Google",
                        "jwt", fakeJwt,
                        "email", email,
                        "fullName", user.getFullName()
                ));
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body("Invalid Google ID token.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Google login failed.");
        }
    }

    //=========================
    //      FIREBASE LOGIN
    //=========================
    /**
     * Authenticates a user by verifying the Firebase ID token.
     * <p>
     * This method verifies the provided Firebase token, retrieves user information,
     * and either fetches an existing user or creates a new user in the database.
     * Upon successful verification, it simulates JWT creation and returns a success response.
     * </p>
     *
     * @param request the {@link FirebaseLoginRequest} containing the Firebase ID token
     * @return a {@link ResponseEntity} containing a success message with a simulated JWT on success,
     *         or an error message with HTTP 401 status if the token is invalid
     */
    public ResponseEntity<?> firebaseLogin(FirebaseLoginRequest request) {
        try {
            FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(request.getFirebaseToken());

            String email = decodedToken.getEmail();
            String name = (String) decodedToken.getClaims().get("name");

            Optional<User> userOpt = userRepository.findByEmail(email);
            User user;

            if (userOpt.isPresent()) {
                user = userOpt.get();
            } else {
                user = new User();
                user.setEmail(email);
                user.setFullName(name);
                user.setEmailVerified(true);
                userRepository.save(user);
            }

            // Simulate JWT generation
            String fakeJwt = "jwt_token_for_" + email;

            return ResponseEntity.ok(Map.of(
                    "message", "Login successful via Firebase",
                    "jwt", fakeJwt
            ));
        } catch (FirebaseAuthException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Firebase token.");
        }
    }

    /**
     * Resets the user's password using a registration passcode.
     * <p>
     * This method verifies the user's email and passcode, checks if the new password and confirmation match,
     * then updates the user's password after encoding it.
     * </p>
     *
     * @param request the {@link ForgotPasswordRequest} containing email, passcode, new password, and confirmation
     * @return a {@link ResponseEntity} with a success message if reset is successful,
     *         or an error message if validation fails
     */
    public ResponseEntity<?> resetPasswordWithPasscode(ForgotPasswordRequest request) {
       
        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());

        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("User not found.");
        }
    
        User user = userOpt.get();
    
        if (user.getPasscode() == null || !user.getPasscode().equals(request.getPasscode())) {
            return ResponseEntity.badRequest().body("Invalid registration passcode.");
        }
    
        String newPassword = request.getNewPassword();
        String confirmPassword = request.getConfirmPassword();
    
        if (!newPassword.equals(confirmPassword)) {
            return ResponseEntity.badRequest().body("Passwords do not match.");
        }
    
        // Password valid and matches, now encode and update
        String hashedPassword = passwordEncoder.encode(newPassword);
        user.setPassword(hashedPassword);
    
        userRepository.save(user);
    
        return ResponseEntity.ok("Password reset successful. You are now logged in.");
    }

}