package com.lendrix.authservice.dto;

/**
 * Data Transfer Object (DTO) representing a login response.
 * Contains a message indicating the result of the login attempt,
 * such as success or failure information.
 * <p>
 * This class is typically used to send feedback to the client
 * after verifying user credentials.
 * </p>
 */
public class LoginResponse {
    private String message;

    /**
     * Default constructor.
     * Required for frameworks that instantiate the object via reflection.
     */
    public LoginResponse() {}

    /**
     * Constructs a LoginResponse with the specified message.
     *
     * @param message the response message indicating login status
     */
    public LoginResponse(String message) {
        this.message = message;
    }

    /**
     * Returns the response message.
     *
     * @return the message as a String
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the response message.
     *
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
