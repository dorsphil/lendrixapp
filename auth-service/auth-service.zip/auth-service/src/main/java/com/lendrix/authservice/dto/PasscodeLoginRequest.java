package com.lendrix.authservice.dto;

/**
 * Data Transfer Object (DTO) for login recovery using a passcode.
 * <p>
 * This DTO contains the user's email address and a passcode, which are used
 * to authenticate the user during the login recovery process.
 * It is typically used when a user opts to log in using a recovery passcode
 * instead of a traditional password or two-factor code.
 * </p>
 */
public class PasscodeLoginRequest {
    private String email;
    private String passcode;

    /**
     * Default constructor.
     * Required for frameworks that instantiate the object via reflection.
     */
    public PasscodeLoginRequest() {}

    /**
     * Constructs a PasscodeLoginRequest with the specified email and passcode.
     *
     * @param email    the user's email address
     * @param passcode the passcode provided for login recovery
     */
    public PasscodeLoginRequest(String email, String passcode) {
        this.email = email;
        this.passcode = passcode;
    }

    /**
     * Returns the user's email address.
     *
     * @return the email address as a String
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the user's email address.
     *
     * @param email the email address to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns the passcode provided for login recovery.
     *
     * @return the passcode as a String
     */
    public String getPasscode() {
        return passcode;
    }

    /**
     * Sets the passcode for login recovery.
     *
     * @param passcode the passcode to set
     */
    public void setPasscode(String passcode) {
        this.passcode = passcode;
    }
}
