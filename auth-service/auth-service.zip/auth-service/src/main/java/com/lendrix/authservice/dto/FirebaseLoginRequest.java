
package com.lendrix.authservice.dto;

/**
 * Data Transfer Object (DTO) for receiving a Firebase ID token from the frontend
 * during Google Sign-In via Firebase Authentication.
 * <p>
 * This DTO contains the Firebase-issued ID token that is obtained after a user
 * successfully logs in with Google through Firebase Authentication.
 * </p>
 */
public class FirebaseLoginRequest {

    /**
     * Firebase-issued ID token obtained after user logs in with Google.
     */
    private String firebaseToken;

    /**
     * Default constructor.
     * Required for frameworks that instantiate the object via reflection.
     */
    public FirebaseLoginRequest() {
    }

    /**
     * Constructs a FirebaseLoginRequest with the specified Firebase ID token.
     *
     * @param firebaseToken the Firebase ID token to be verified
     */
    public FirebaseLoginRequest(String firebaseToken) {
        this.firebaseToken = firebaseToken;
    }

    /**
     * Returns the Firebase ID token provided by the client.
     *
     * @return the Firebase ID token as a String
     */
    public String getFirebaseToken() {
        return firebaseToken;
    }

    /**
     * Sets the Firebase ID token for this request.
     *
     * @param firebaseToken the Firebase ID token to set
     */
    public void setFirebaseToken(String firebaseToken) {
        this.firebaseToken = firebaseToken;
    }
}

