package com.lendrix.authservice.service;

import com.lendrix.authservice.model.PhoneVerificationCode;
import com.lendrix.authservice.model.User;
import com.lendrix.authservice.repository.PhoneVerificationCodeRepository;
import com.lendrix.authservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

/**
 * Service responsible for handling phone number verification processes.
 * <p>
 * This service allows initiating a phone verification by generating and sending a verification code,
 * and verifying the code entered by the user.
 * </p>
 * <p>
 * It interacts with {@link UserRepository} and {@link PhoneVerificationCodeRepository} to manage users
 * and their phone verification codes.
 * </p>
 * 
 * <p><b>Usage example:</b></p>
 * <pre>
 *   phoneVerificationService.initiateVerification("user@example.com", "1234567890");
 *   boolean verified = phoneVerificationService.verifyCode("user@example.com", "123456");
 * </pre>
 * 
 * @see User
 * @see PhoneVerificationCode
 * @see UserRepository
 * @see PhoneVerificationCodeRepository
 */
@Service
public class PhoneVerificationService {

    @Autowired
    private PhoneVerificationCodeRepository codeRepository;

    @Autowired
    private UserRepository userRepository;

    /**
     * Starts the phone verification process for a user identified by their email.
     * <p>
     * This method:
     * <ul>
     *   <li>Finds the user by email.</li>
     *   <li>Updates the user's phone number.</li>
     *   <li>Generates a random 6-digit verification code.</li>
     *   <li>Sets an expiry time for the code (2 minutes from now).</li>
     *   <li>Saves the verification code linked to the user.</li>
     *   <li>Simulates sending the code via SMS (prints to console).</li>
     * </ul>
     * 
     * @param email the email of the user to verify the phone number for
     * @param phoneNumber the phone number to verify
     * @throws RuntimeException if no user is found with the given email
     */
    public void initiateVerification(String email, String phoneNumber) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        if (optionalUser.isEmpty()) throw new RuntimeException("User not found");

        User user = optionalUser.get();
        user.setPhoneNumber(phoneNumber);
        userRepository.save(user);

        String code = String.valueOf(100000 + new Random().nextInt(900000)); // 6-digit code
        LocalDateTime expiry = LocalDateTime.now().plusMinutes(2);

        PhoneVerificationCode pvc = new PhoneVerificationCode();
        pvc.setPhoneNumber(phoneNumber);
        pvc.setCode(code);
        pvc.setExpiryTime(expiry);
        pvc.setUser(user);

        codeRepository.save(pvc);

        // Simulate SMS sending (replace with real SMS service like Twilio)
        System.out.println("Sending SMS to " + phoneNumber + ": Your code is " + code);
    }

    /**
     * Verifies the phone verification code entered by the user.
     * <p>
     * This method:
     * <ul>
     *   <li>Finds the user by email.</li>
     *   <li>Retrieves the stored verification code for the user's phone number.</li>
     *   <li>Checks if the input code matches the stored code and if it has not expired.</li>
     *   <li>If valid, marks the user's phone as verified and removes the used code.</li>
     * </ul>
     * 
     * @param email the email of the user attempting verification
     * @param codeInput the verification code entered by the user
     * @return {@code true} if the code is valid and verification succeeds; {@code false} otherwise
     */
    public boolean verifyCode(String email, String codeInput) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        if (optionalUser.isEmpty()) return false;

        User user = optionalUser.get();
        Optional<PhoneVerificationCode> optionalCode = codeRepository.findByPhoneNumber(user.getPhoneNumber());

        if (optionalCode.isPresent()) {
            PhoneVerificationCode pvc = optionalCode.get();
            if (pvc.getCode().equals(codeInput) && pvc.getExpiryTime().isAfter(LocalDateTime.now())) {
                user.setPhoneVerified(true);
                userRepository.save(user);
                codeRepository.delete(pvc); // optional: remove used code
                return true;
            }
        }

        return false;
    }
}
