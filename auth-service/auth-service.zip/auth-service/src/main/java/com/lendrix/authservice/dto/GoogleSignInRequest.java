package com.lendrix.authservice.dto;

/**
 * Data Transfer Object (DTO) for receiving a Google ID token from the client.
 * <p>
 * This DTO contains the ID token issued by Google after a successful sign-in,
 * which is typically sent from the frontend to the backend for verification and authentication.
 * </p>
 */
public class GoogleSignInRequest {
    private String idToken;

    /**
     * Default constructor.
     * Required for frameworks that instantiate the object via reflection.
     */
    public GoogleSignInRequest() {}

    /**
     * Constructs a GoogleSignInRequest with the specified Google ID token.
     *
     * @param idToken the Google ID token to be verified
     */
    public GoogleSignInRequest(String idToken) {
        this.idToken = idToken;
    }

    /**
     * Returns the Google ID token provided by the client.
     *
     * @return the Google ID token as a String
     */
    public String getIdToken() {
        return idToken;
    }

    /**
     * Sets the Google ID token for this request.
     *
     * @param idToken the Google ID token to set
     */
    public void setIdToken(String idToken) {
        this.idToken = idToken;
    }
}
