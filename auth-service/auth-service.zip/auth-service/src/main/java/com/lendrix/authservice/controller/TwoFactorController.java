package com.lendrix.authservice.controller;

import com.lendrix.authservice.dto.TwoFactorCodeRequest;
import com.lendrix.authservice.dto.TwoFactorVerifyRequest;
import com.lendrix.authservice.service.TwoFactorService;
import com.lendrix.authservice.dto.PasscodeLoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for handling two-factor authentication (2FA) related endpoints.
 * <p>
 * This controller exposes API endpoints to send a 2FA verification code via SMS
 * and to verify the submitted 2FA code.
 * </p>
 * <p>
 * Endpoints:
 * <ul>
 *   <li><code>POST /api/auth/2fa/send-code</code> - Initiates sending a 2FA code to the user's phone.</li>
 *   <li><code>POST /api/auth/2fa/verify-code</code> - Verifies the 2FA code submitted by the user.</li>
 * </ul>
 * </p>
 */
@RestController
@RequestMapping("/api/auth/2fa")
public class TwoFactorController {

    @Autowired
    private TwoFactorService twoFactorService;

    /**
     * Sends a two-factor authentication (2FA) code to the user's registered phone number.
     *
     * @param request the request containing the user's email address
     * @return a ResponseEntity containing a success or error message
     */
    @PostMapping("/send-code")
    public ResponseEntity<String> sendCode(@RequestBody TwoFactorCodeRequest request) {
        return twoFactorService.sendCode(request);
    }

    /**
     * Verifies the two-factor authentication (2FA) code submitted by the user.
     *
     * @param request the request containing the user's email and the 2FA code to verify
     * @return a ResponseEntity containing a success or error message based on verification result
     */
    @PostMapping("/verify-code")
    public ResponseEntity<String> verifyCode(@RequestBody TwoFactorVerifyRequest request) {
        return twoFactorService.verifyCode(request);
    }

    @PostMapping("/passcode-login")
    public ResponseEntity<String> loginWithPasscode(@RequestBody PasscodeLoginRequest request) {
        return twoFactorService.loginWithPasscode(request);
    }
}
