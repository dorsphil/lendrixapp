package com.lendrix.authservice.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.OneToOne;
import jakarta.persistence.FetchType;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Entity representing a verification token used for user account verification processes,
 * such as email confirmation or password reset.
 *
 * <p>
 * Each token is associated with a specific {@link User} and has an expiry date.
 * </p>
 * 
 * @author: Dorsphil Osei
 *          dorsphillloseiasuming@gmail.com
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class VerificationToken {

    /**
     * Unique identifier for the verification token.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * The token string used for verification.
     */
    private String token;

    /**
     * The user associated with this verification token.
     */
    @OneToOne(targetEntity = User.class, fetch = FetchType.EAGER)
    private User user;

    /**
     * The date and time when the token expires.
     */
    private LocalDateTime expiryDate;

    // Getters, setters, constructors, and other methods omitted for brevity.
}
