package com.lendrix.authservice.dto;

/**
 * Data Transfer Object (DTO) representing a request to verify a two-factor authentication (2FA) code.
 * <p>
 * This DTO contains the user's email address and the 6-digit SMS code that the user received
 * and wishes to verify as part of the authentication process.
 * </p>
 */
public class TwoFactorVerifyRequest {
    private String email;
    private String code;

    /**
     * Default constructor.
     * Required for frameworks that instantiate the object via reflection.
     */
    public TwoFactorVerifyRequest() {
    }

    /**
     * Constructs a TwoFactorVerifyRequest with the specified email and verification code.
     *
     * @param email the email address of the user attempting verification
     * @param code  the 6-digit SMS verification code to verify
     */
    public TwoFactorVerifyRequest(String email, String code) {
        this.email = email;
        this.code = code;
    }

    /**
     * Returns the email address associated with this verification request.
     *
     * @return the user's email address as a String
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address for this verification request.
     *
     * @param email the user's email address to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns the 6-digit SMS verification code.
     *
     * @return the verification code as a String
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the 6-digit SMS verification code.
     *
     * @param code the verification code to set
     */
    public void setCode(String code) {
        this.code = code;
    }
}
