package com.lendrix.authservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.lendrix.authservice.model.User;

/**
 * Service responsible for sending email notifications to users.
 * 
 * <p>
 * Currently supports sending verification emails with a token-based verification link.
 * </p>
 * 
 * @author  Dorsphil Osei
 *          dorsphillloseiasuming@gmail.com
 */
@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    /**
     * Sends a verification email to the specified user containing a link with the verification token.
     *
     * @param user  the user to whom the verification email will be sent
     * @param token the verification token to be included in the verification link
     */
    public void sendVerificationEmail(User user, String token) {
        String url = "http://localhost:8081/api/auth/verify-email?token=" + token;
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(user.getEmail());
        message.setSubject("Verify your email");
        message.setText("Click this link to verify your email: " + url);
        //mailSender.send(message);
        System.out.println("DEV EMAIL: http://localhost:8081/api/auth/verify-email?token=" + token);


    }

}
