package com.lendrix.authservice.dto;

import lombok.Data;

/**
 * Data Transfer Object (DTO) representing a request to verify a phone code.
 * <p>
 * This class contains the user's email and the verification code that the user submits
 * to confirm their phone number.
 * </p>
 * 
 * <ul>
 *   <li><b>email:</b> The email address of the user attempting verification.</li>
 *   <li><b>code:</b> The verification code received by the user on their phone.</li>
 * </ul>
 * 
 * This DTO is typically used as the request body in API calls for phone code verification.
 */
@Data
public class PhoneCodeVerificationRequest {
    /**
     * The email address of the user.
     */
    private String email;

    /**
     * The verification code sent to the user's phone.
     */
    private String code;
}
