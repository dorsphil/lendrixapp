package com.lendrix.authservice.dto;

import lombok.Data;

/**
 * Data Transfer Object (DTO) representing a request to initiate phone verification.
 * <p>
 * This class contains the user's email and phone number that are required
 * to start the phone verification process.
 * </p>
 * 
 * <ul>
 *   <li><b>email:</b> The email address of the user requesting verification.</li>
 *   <li><b>phoneNumber:</b> The phone number to be verified.</li>
 * </ul>
 * 
 * This DTO is typically used as the request body in API calls.
 */
@Data
public class PhoneVerificationRequest {
    /**
     * The email address of the user.
     */
    private String email;

    /**
     * The phone number to verify.
     */
    private String phoneNumber;
}
