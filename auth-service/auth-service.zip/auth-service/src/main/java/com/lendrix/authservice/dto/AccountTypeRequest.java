package com.lendrix.authservice.dto;

import lombok.Data;

/**
 * DTO representing a request to set the account type for a user.
 */
@Data
public class AccountTypeRequest {
    private String email;
    private String accountType;  // Expected values: "Personal" or "Business"
}
