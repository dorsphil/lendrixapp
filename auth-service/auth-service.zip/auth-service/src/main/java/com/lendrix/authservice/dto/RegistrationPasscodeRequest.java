package com.lendrix.authservice.dto;

/**
 * Data Transfer Object (DTO) for receiving the 4-digit registration passcode from the user.
 * <p>
 * This DTO contains the user's email address and the passcode entered during the registration process.
 * It is typically used to validate the passcode sent to the user's email or phone as part of multi-step registration.
 * </p>
 */
public class RegistrationPasscodeRequest {
    private String email;
    private String passcode;

    /**
     * Default constructor.
     * Required for frameworks that instantiate the object via reflection.
     */
    public RegistrationPasscodeRequest() {}

    /**
     * Constructs a RegistrationPasscodeRequest with the specified email and passcode.
     *
     * @param email    the user's email address
     * @param passcode the 4-digit passcode submitted by the user
     */
    public RegistrationPasscodeRequest(String email, String passcode) {
        this.email = email;
        this.passcode = passcode;
    }

    /**
     * Returns the user's email address.
     *
     * @return the email address as a String
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the user's email address.
     *
     * @param email the email address to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns the 4-digit passcode submitted by the user.
     *
     * @return the passcode as a String
     */
    public String getPasscode() {
        return passcode;
    }

    /**
     * Sets the 4-digit passcode.
     *
     * @param passcode the passcode to set
     */
    public void setPasscode(String passcode) {
        this.passcode = passcode;
    }
}
