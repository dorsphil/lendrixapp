package com.lendrix.authservice.config;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * Configuration class to initialize Firebase SDK within the Spring Boot application.
 * <p>
 * This class reads the Firebase service account credentials from a JSON file and
 * initializes the FirebaseApp instance at application startup.
 * </p>
 * <p>
 * The {@link PostConstruct} annotated {@code init()} method ensures that Firebase is
 * configured once the Spring context is fully initialized.
 * </p>
 * <p>
 * This setup enables the application to use Firebase services such as Authentication,
 * Cloud Messaging, and Firestore.
 * </p>
 */
@Configuration
@ConditionalOnProperty(name = "firebase.enabled", havingValue = "true")
public class FirebaseConfig {

    /**
     * Initializes the FirebaseApp instance using service account credentials.
     *
     * @throws IOException if the service account JSON file cannot be read
     */
    @PostConstruct
    public void init() throws IOException {
        FileInputStream serviceAccount = new FileInputStream("firebase-admin-sdk.json");

        FirebaseOptions options = FirebaseOptions.builder()
                .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                .build();

        if (FirebaseApp.getApps().isEmpty()) {
            FirebaseApp.initializeApp(options);
        }
    }
}
