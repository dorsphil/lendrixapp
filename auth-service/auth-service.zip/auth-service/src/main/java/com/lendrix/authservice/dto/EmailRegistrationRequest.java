package com.lendrix.authservice.dto;

import lombok.Data;

@Data
public class EmailRegistrationRequest {
    private String email;
    private String fullName;
}
