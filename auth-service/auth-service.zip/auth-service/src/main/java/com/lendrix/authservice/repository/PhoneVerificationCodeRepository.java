package com.lendrix.authservice.repository;

import com.lendrix.authservice.model.PhoneVerificationCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface for managing PhoneVerificationCode entities.
 * 
 * @author Dorsphil Osei <dorsphillloseiasuming@gmail.com>
 */
@Repository
public interface PhoneVerificationCodeRepository extends JpaRepository<PhoneVerificationCode, Long> {
    
    /**
     * Find a phone verification code by phone number
     * 
     * @param phoneNumber the phone number to search for
     * @return Optional containing the verification code if found
     */
    Optional<PhoneVerificationCode> findByPhoneNumber(String phoneNumber);
    
    /**
     * Find a phone verification code by user email (through user relationship)
     * 
     * @param email the user's email
     * @return Optional containing the verification code if found
     */
    Optional<PhoneVerificationCode> findByUserEmail(String email);
}