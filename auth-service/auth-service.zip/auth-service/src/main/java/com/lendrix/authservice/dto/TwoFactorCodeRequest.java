package com.lendrix.authservice.dto;

/**
 * Data Transfer Object (DTO) representing a request to send a two-factor authentication (2FA) code via SMS.
 * <p>
 * This DTO contains the user's email address, which is used to identify the recipient of the 2FA code.
 * </p>
 * <p>
 * Typically used in authentication services to initiate the sending of a 2FA code for enhanced security.
 * </p>
 */
public class TwoFactorCodeRequest {
    private String email;

    /**
     * Default constructor.
     * Required for frameworks that instantiate the object via reflection.
     */
    public TwoFactorCodeRequest() {
    }

    /**
     * Constructs a TwoFactorCodeRequest with the specified email address.
     *
     * @param email the email address to which the 2FA code will be sent
     */
    public TwoFactorCodeRequest(String email) {
        this.email = email;
    }

    /**
     * Returns the email address associated with this 2FA code request.
     *
     * @return the email address as a String
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address for this 2FA code request.
     *
     * @param email the email address to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
