package com.lendrix.authservice.dto;

import lombok.Data;

@Data
public class CountrySelectionRequest {
    private String email;
    private String country;
}
