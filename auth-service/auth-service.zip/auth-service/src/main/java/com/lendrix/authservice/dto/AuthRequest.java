package com.lendrix.authservice.dto;

/**
 * Data Transfer Object (DTO) for authentication requests.
 * <p>
 * This class encapsulates the data required for login or registration operations,
 * specifically the user's email and password.
 * It is used to transfer authentication data between client and server layers,
 * without exposing any business logic.
 * </p>
 * <p>
 * Typical usage includes receiving JSON request bodies in REST APIs and mapping them to this DTO.
 * </p>
 * 
 * <p><b>Fields:</b></p>
 * <ul>
 *   <li><b>email</b> - The user's email address used as the login identifier.</li>
 *   <li><b>password</b> - The user's password for authentication.</li>
 * </ul>
 * 
 * <p>This class provides constructors for easy instantiation, as well as standard getters and setters.</p>
 * 
 * @author  Dorsphil Osei
 *          dorsphillloseiasuming@gmail.com 
 * 
 * @version 1.0
 */

public class AuthRequest {

    /**
     * The email address of the user.
     */
    private String email;

    /**
     * The password of the user.
     */
    private String password;

    /** 
     * The full name of the user
    */
    private String fullName;

    /**
     * Default no-argument constructor.
     */
    public AuthRequest() {

    }

    

    /**
     * Returns the user's email address.
     * 
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the user's email address.
     * 
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns the user's password.
     * 
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the user's password.
     * 
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

     /**
     * Returns the user's full name
     * 
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * Sets the user's email address.
     * 
     * @param email the email to set
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * Constructs an AuthRequest with the specified email and password.
     * 
     * @param email the user's email address
     * @param password the user's password
     */
    //public AuthRequest(String email, String password, String fullName) {
        //this.email = email;
        //this.password = password;
        //this.fullName = fullName;
    //}
}
