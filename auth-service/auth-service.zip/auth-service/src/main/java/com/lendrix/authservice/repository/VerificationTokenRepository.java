package com.lendrix.authservice.repository;

// JPA repository for CRUD operations
import org.springframework.data.jpa.repository.JpaRepository;

// Optional container for nullable return values
import java.util.Optional;

// VerificationToken entity
import com.lendrix.authservice.model.VerificationToken;

/**
 * Repository interface for managing VerificationToken entities.
 * Extends JpaRepository to provide CRUD and custom finder methods.
 * 
 * @author  Dorsphil Osei
 *          dorsphillloseiasuming@gmail.com
 */
public interface VerificationTokenRepository extends JpaRepository<VerificationToken, Long> {

    /**
     * Find a VerificationToken by its token string.
     *
     * @param token the verification token string
     * @return Optional containing the VerificationToken if found, or empty otherwise
     */
    Optional<VerificationToken> findByToken(String token);
}
