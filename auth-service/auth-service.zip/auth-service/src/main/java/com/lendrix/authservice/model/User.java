package com.lendrix.authservice.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.OneToOne;
import jakarta.persistence.FetchType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Represents a user entity in the authentication service.
 * <p>
 * This class is mapped to the "users" table in the database using JPA annotations.
 * It contains basic user information such as username and password.
 * Lombok annotations are used to generate boilerplate code like getters, setters,
 * constructors, and builder pattern implementation.
 * </p>
 * 
 * <p><b>Database Table:</b> users</p>
 * 
 * <p><b>Fields:</b></p>
 * <ul>
 *   <li><b>id</b> - Primary key, auto-generated unique identifier for the user.</li>
 *   <li><b>username</b> - Unique username, cannot be null.</li>
 *   <li><b>password</b> - Password for authentication, cannot be null.</li>
 * </ul>
 * 
 * <p>Additional fields such as email, roles, etc., can be added as needed.</p>
 * 
 * @author: Dorsphil Osei
 *          dorsphilloseiasuming@gmail.com
 * 
 * @date:   21 May, 2025
 */

    @Entity
    @Table(name = "users")
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public class User {

    /**
     * Unique identifier for the user.
     * This is the primary key and is generated automatically by the database.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Full name of the user.
     * This field cannot be null.
     */
    @Column(nullable = false)
    private String fullName;

    /**
     * email of the user.
     * This must be unique and cannot be null.
     */
    @Column(nullable = false, unique = true)
    private String email;

    /**
     * Password of the user.
     * This field cannot be null.
     */
    @Column(nullable = false)
    private String password;

    /**
     * The country of residence of the user.
     */
    @Column
    private String countryOfResidence;

    /**
     * The type of user account: "Personal" or "Business".
     */
    private String accountType; 
    
    /* the user's phone number for verification*/
    private String phoneNumber;

    
    private boolean phoneVerified;



    @Builder.Default
    private boolean emailVerified = false;

    public User(String email, String password, String fullName) {
        this.fullName = fullName;
        this.email = email;
        this.password = password;
    }

    /**
     * a passcode set by the user for account verification
     * during login
     * It is saved in the database at the registration stage
     * and referenced later during login
     */

    @Column(name = "passcode")
    private String passcode;

    public String getPasscode() {
        return passcode;
    }

    public void setPasscode(String passcode) {
        this.passcode = passcode;
    }

    //public boolean isEmailVerified() { return emailVerified; }
    //public void setEmailVerified(boolean emailVerified) { this.emailVerified = emailVerified; }


    

    // TODO: add Google sign-in info or roles later as needed
}