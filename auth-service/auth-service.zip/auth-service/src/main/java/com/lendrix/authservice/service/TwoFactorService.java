package com.lendrix.authservice.service;

import com.lendrix.authservice.dto.PasscodeLoginRequest;
import com.lendrix.authservice.dto.TwoFactorCodeRequest;
import com.lendrix.authservice.dto.TwoFactorVerifyRequest;
import com.lendrix.authservice.model.PhoneVerificationCode;
import com.lendrix.authservice.model.User;
import com.lendrix.authservice.repository.PhoneVerificationCodeRepository;
import com.lendrix.authservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

/**
 * Service class for handling two-factor authentication (2FA) via SMS.
 * <p>
 * This service is responsible for generating, storing, and sending verification codes
 * to users' registered phone numbers as part of the authentication process.
 * </p>
 * <p>
 * Typical usage involves calling {@link #sendCode(TwoFactorCodeRequest)} with a user's email,
 * which triggers the process of code generation, persistence, and simulated SMS delivery.
 * </p>
 */
@Service
public class TwoFactorService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PhoneVerificationCodeRepository codeRepository;

    /**
     * Generates and sends a two-factor authentication (2FA) code to the user's registered phone number.
     * <p>
     * The method performs the following steps:
     * <ul>
     *     <li>Looks up the user by email.</li>
     *     <li>Checks if the user has a registered phone number.</li>
     *     <li>Generates a random 6-digit verification code.</li>
     *     <li>Saves the code and its expiry time to the database.</li>
     *     <li>Simulates sending the code via SMS (prints to console).</li>
     * </ul>
     * </p>
     *
     * @param request the request containing the user's email address
     * @return a ResponseEntity with a success or error message
     */
    public ResponseEntity<String> sendCode(TwoFactorCodeRequest request) {
        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());

        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("User not found");
        }

        User user = userOpt.get();

        if (user.getPhoneNumber() == null || user.getPhoneNumber().isEmpty()) {
            return ResponseEntity.badRequest().body("User has no phone number registered.");
        }

        String code = String.format("%06d", new Random().nextInt(999999));
        LocalDateTime expiry = LocalDateTime.now().plusMinutes(5);

        PhoneVerificationCode codeEntity = new PhoneVerificationCode();
        codeEntity.setPhoneNumber(user.getPhoneNumber());
        codeEntity.setCode(code);
        codeEntity.setExpiryTime(expiry);

        codeRepository.save(codeEntity);

        // Simulate SMS send
        System.out.println("Sending 2FA code to " + user.getPhoneNumber() + ": " + code);

        return ResponseEntity.ok("Verification code sent to your phone.");
    }

        public ResponseEntity<String> verifyCode(TwoFactorVerifyRequest request) {
        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());

        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("User not found");
        }

        User user = userOpt.get();

        Optional<PhoneVerificationCode> codeOpt =
                codeRepository.findByPhoneNumber(user.getPhoneNumber());

        if (codeOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("No verification code found.");
        }

        PhoneVerificationCode codeEntity = codeOpt.get();

        if (!codeEntity.getCode().equals(request.getCode())) {
            return ResponseEntity.badRequest().body("Invalid verification code.");
        }

        if (codeEntity.getExpiryTime().isBefore(LocalDateTime.now())) {
            return ResponseEntity.badRequest().body("Verification code has expired.");
        }

        // SIMULATE login success & JWT generation
        return ResponseEntity.ok("Login complete. Welcome to your Lendrix account.");
    }

    /**
     * Authenticates a user by verifying the provided passcode for login recovery.
     * <p>
     * The method performs the following steps:
     * <ul>
     *     <li>Looks up the user by the provided email address.</li>
     *     <li>Checks if the user has a passcode set for login recovery.</li>
     *     <li>Compares the provided passcode with the stored passcode.</li>
     *     <li>Returns appropriate HTTP responses indicating success or specific failure reasons.</li>
     * </ul>
     * </p>
     * <p>
     * Note: This method simulates a successful login upon passcode verification.
     * </p>
     *
     * @param request the {@link PasscodeLoginRequest} containing the user's email and passcode
     * @return a {@link ResponseEntity} containing a success message if authentication passes,
     *         or an error message if authentication fails (user not found, no passcode set, or invalid passcode)
     */
    public ResponseEntity<String> loginWithPasscode(PasscodeLoginRequest request) {
        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());

        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("User not found.");
        }

        User user = userOpt.get();

        if (user.getPasscode() == null) {
            return ResponseEntity.badRequest().body("No passcode found for this user.");
        }

        if (!user.getPasscode().equals(request.getPasscode())) {
            return ResponseEntity.badRequest().body("Invalid passcode.");
        }

        // Simulate login success
        return ResponseEntity.ok("Login successful via passcode. Welcome back.");
    }


}
