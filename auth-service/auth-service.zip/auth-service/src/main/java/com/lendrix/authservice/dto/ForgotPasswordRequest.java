package com.lendrix.authservice.dto;

/**
 * Data Transfer Object (DTO) for handling password reset requests using a registration passcode.
 * <p>
 * This DTO captures the user's email, the registration passcode for verification,
 * and the new password along with its confirmation for resetting the password.
 * </p>
 */
public class ForgotPasswordRequest {
    private String email;
    private String passcode;
    private String newPassword;
    private String confirmPassword;

    /**
     * Default constructor.
     * Required for frameworks that instantiate the object via reflection.
     */
    public ForgotPasswordRequest() {
    }

    /**
     * Constructs a ForgotPasswordRequest with the specified details.
     *
     * @param email           the user's email address
     * @param passcode        the registration passcode used for verification
     * @param newPassword     the new password to set
     * @param confirmPassword confirmation of the new password
     */
    public ForgotPasswordRequest(String email, String passcode, String newPassword, String confirmPassword) {
        this.email = email;
        this.passcode = passcode;
        this.newPassword = newPassword;
        this.confirmPassword = confirmPassword;
    }

    /**
     * Returns the user's email address.
     *
     * @return the email address as a String
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the user's email address.
     *
     * @param email the email address to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns the registration passcode used for verification.
     *
     * @return the passcode as a String
     */
    public String getPasscode() {
        return passcode;
    }

    /**
     * Sets the registration passcode used for verification.
     *
     * @param passcode the passcode to set
     */
    public void setPasscode(String passcode) {
        this.passcode = passcode;
    }

    /**
     * Returns the new password to be set.
     *
     * @return the new password as a String
     */
    public String getNewPassword() {
        return newPassword;
    }

    /**
     * Sets the new password to be set.
     *
     * @param newPassword the new password to set
     */
    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    /**
     * Returns the confirmation of the new password.
     *
     * @return the confirmation password as a String
     */
    public String getConfirmPassword() {
        return confirmPassword;
    }

    /**
     * Sets the confirmation of the new password.
     *
     * @param confirmPassword the confirmation password to set
     */
    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }
}
