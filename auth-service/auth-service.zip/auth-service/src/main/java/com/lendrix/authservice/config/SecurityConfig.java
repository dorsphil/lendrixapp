package com.lendrix.authservice.config;

// Marks this class as a configuration for Spring
import org.springframework.context.annotation.Configuration;

// Indicates a bean definition method
import org.springframework.context.annotation.Bean;

// Used to configure web based security for specific http requests
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

// Represents the security filter chain for HTTP requests
import org.springframework.security.web.SecurityFilterChain;

// Password encoder for hashing passwords
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * Security configuration class for the authentication service.
 * <p>
 * Configures the Spring Security filter chain for HTTP requests and provides password encoding.
 * Currently, CSRF protection is disabled and all HTTP requests are permitted without authentication.
 * </p>
 * <p>
 * This configuration is typically used during development or for services that do not require authentication.
 * For production, you should customize this configuration to enforce security policies.
 * </p>
 * 
 * @author  Dorsphil Osei
 *          dorsphillloseiasuming@gmail.com
 * 
 * @version 1.0
 */
@Configuration
public class SecurityConfig {

    /**
     * Defines the security filter chain bean.
     * <p>
     * Disables CSRF protection and allows all HTTP requests without authentication.
     * </p>
     * 
     * @param http the {@link HttpSecurity} to configure
     * @return the configured {@link SecurityFilterChain}
     * @throws Exception if an error occurs during configuration
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(auth -> auth.anyRequest()
            .permitAll())
            .csrf(csrf -> csrf.disable());
        return http.build();
    }

    /**
     * Defines the password encoder bean.
     * <p>
     * Uses BCrypt hashing algorithm which is recommended for production use.
     * BCrypt automatically handles salt generation and is resistant to rainbow table attacks.
     * </p>
     * 
     * @return a {@link BCryptPasswordEncoder} instance
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}