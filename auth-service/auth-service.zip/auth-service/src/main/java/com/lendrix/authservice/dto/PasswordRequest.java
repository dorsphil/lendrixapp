package com.lendrix.authservice.dto;

import lombok.Data;

/**
 * Data Transfer Object (DTO) used for the password creation step during user registration.
 * <p>
 * This class holds the user's email and the password they wish to set.
 * It is typically used in the final stage of the registration process,
 * where the user provides their email and chooses a password.
 * </p>
 *
 * <p>
 * Example usage:
 * <pre>
 *     PasswordRequest request = new PasswordRequest();
 *     request.setEmail("user@example.com");
 *     request.setPassword("securePassword123");
 * </pre>
 * </p>
 *
 * @author [Your Name]
 */
@Data
public class PasswordRequest {
    /**
     * The email address of the user registering an account.
     */
    private String email;

    /**
     * The password chosen by the user for their account.
     */
    private String password;
}
