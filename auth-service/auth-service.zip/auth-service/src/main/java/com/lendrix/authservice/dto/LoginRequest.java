package com.lendrix.authservice.dto;

/**
 * Data Transfer Object (DTO) representing a login request.
 * Contains the user's email and password used for authentication.
 * <p>
 * This class is a simple POJO with getters and setters for serialization
 * and deserialization purposes, typically used in REST API request payloads.
 * </p>
 */
public class LoginRequest {
    private String email;
    private String password;

    /**
     * Default constructor.
     * Required for frameworks that instantiate the object via reflection.
     */
    public LoginRequest() {}

    /**
     * Constructs a LoginRequest with the specified email and password.
     *
     * @param email    the user's email address
     * @param password the user's password
     */
    public LoginRequest(String email, String password) {
        this.email = email;
        this.password = password;
    }

    /**
     * Returns the email address of the user.
     *
     * @return the email address as a String
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address of the user.
     *
     * @param email the email address to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns the password of the user.
     *
     * @return the password as a String
     */
    public String getPassword() {
        return password;
    }

}
