package com.lendrix.authservice.repository;

/**
 * Repository interface for managing {@link com.lendrix.authservice.entity.User} entities.
 * <p>
 * Extends {@link org.springframework.data.jpa.repository.JpaRepository} to provide standard CRUD operations,
 * pagination, and sorting for User entities with a primary key of type {@link Long}.
 * </p>
 * <p>
 * Additionally, declares a method to find a User by their email address.
 * Spring Data JPA will automatically implement this method based on the method name.
 * </p>
 * 
 * <p><b>Usage example:</b></p>
 * <pre>
 * {@code
 * Optional<User> user = userRepository.findByEmail("user@example.com");
 * }
 * </pre>
 * 
 * @see org.springframework.data.jpa.repository.JpaRepository
 * @see com.lendrix.authservice.model.User
 * 
 * @author  Dorsphil Osei
 *          dorsphillloseiasuming@gmail.com
 * 
 * @version 1.0
 */

import com.lendrix.authservice.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Retrieves a user by their email address.
     *
     * @param email the email address to search for
     * @return an {@link Optional} containing the User if found, or empty if not found
     */
    Optional<User> findByEmail(String email);
}
