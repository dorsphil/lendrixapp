package com.lendrix.authservice.dto;

// Lombok annotation to generate getters, setters, toString, equals, and hashCode
import lombok.Data;

// Lombok annotation to implement the builder pattern
import lombok.Builder;

// Lombok annotation to generate a no-argument constructor
import lombok.NoArgsConstructor;

// Lombok annotation to generate an all-arguments constructor
import lombok.AllArgsConstructor;

/**
 * Data Transfer Object for capturing user registration details.
 * <p>
 * This class contains the necessary fields required when a user registers:
 * email, password, first name, last name, and account type (e.g., "PERSONAL" or "BUSINESS").
 * It is used to transfer registration data from the client to the server.
 * </p>
 * 
 * @author  Dorsphil Osei
 *          dorsphillloseiasuming@gmail.com
 * 
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class RegisterRequest {
    private String email;
    private String password;
    private String fullName;
    private String accountType; // e.g., "PERSONAL" or "BUSINESS"
}
