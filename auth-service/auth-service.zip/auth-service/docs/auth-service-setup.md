# Auth Service Setup Documentation

## Project Structure
auth-service/
- ├── src/
- │   └── main/
- │       ├── java/com/lendrix/authservice/
- │       │   ├── controller/
- │       │   │   └── AuthController.java
- │       │   ├── dto/
- │       │   │   ├── LoginRequest.java
- │       │   │   ├── RegisterRequest.java
- │       │   ├── entity/
- │       │   │   └── User.java
- │       │   ├── repository/
- │       │   │   └── UserRepository.java
- │       │   ├── service/
- │       │   │   └── AuthService.java
- │       │   └── AuthServiceApplication.java
- ├── application.properties

## Step 1: Initialize Spring Boot Project

**Microservice name**:  auth-service

- **Tool Used**: [Spring Initializr](https://start.spring.io/)
- **Project Metadata**:                   
  - Project: Maven  -Dependency and build tool
  - Language: Java
  - Spring Boot: 3.2.5
  - Group: 'com.lendrix'
  - Artifact: 'auth-service'
  - Name: 'auth-service'
  - Package name: 'com.lendrix.authservice'
  - Packaging: Jar
  - Java: 17

- **Dependencies**:
  - Spring Web  -To expose REST APIs
  - Spring Boot DevTools
  - Spring Security -For authentication and authorization
  - Spring Data JPA -ORM to interact with PostgreSQL
  - PostgreSQL Driver -Connects the service to a PostgreSQL database

- **Downloaded the generated ZIP and extract it.**

---

## Step 2: Open Project in VS Code

```bash
cd auth-service
code .
```
## Step 3:  Run the Spring Boot App

**Location**: src/main/java/com/wiseclone/authservice/AuthServiceApplication.java

- Ran the project using 
  ```bash
    ./mvnw spring-boot:run
  ```
- Build Success Confirmed

## Notes

- I used VS Code on Linux Mint 21.3 to open the extracted project folder.
- No errors during project generation or extraction.
- Dependencies were chosen based on our project requirement (authentication with PostgreSQL).
- This is just the project skeleton.

## Step 4:  PostgreSQL Database Setup

**Tools Used**
- PostgreSql
- Terminal(Linux Mint)

**Steps**
1. Login to PostgreSQL
```sudo -u postgres psql ```
2. Create the database
```CREATE DATABASE authdb;``` <!--name of database is authdb-->
3. Grant privileges to dorsphil(database username)
```GRANT ALL PRIVILEGES ON DATABASE authdb TO dorsphil;```

## Configure application.properties

  **Location**: src/main/resources/application.properties

**Goal**
- Tell Spring Boot how to connect to the PostgreSQL Database
- Set some Spring settings

**Open the application.properties file to type the configuration**

```properties
# ========== Database Configuration ==========
spring.datasource.url=jdbc:postgresql://localhost:5432/authdb
spring.datasource.username=dorsphil
spring.datasource.password=dorsphil123
spring.datasource.driver-class-name=org.postgresql.Driver

# ========== JPA / Hibernate ==========
spring.jpa.show-sql=true
spring.jpa.hibernate.ddl-auto=update
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.PostgreSQLDialect

# ========== Server Port (optional) ==========
# If you want auth-service to run on a different port than default 8080
server.port=8081

# ========== JWT Secret (placeholder for now) ==========
jwt.secret=my-secret-key
jwt.expiration=3600000
```
**Explanation**
- spring.datasource.url → The name of the database you'll use (you’ll create it next).
- spring.jpa.hibernate.ddl-auto=update → Automatically creates tables based on your entities.
- server.port=8081 → Prevents conflict if other services use 8080.
- jwt.secret → Will be used later for generating tokens.

## Notes
- PostgreSQL must be running when the Spring Boot app is started
- The port 8081 was used to avoid potential conflicts with other microservices from the default 8080.

## Step 5: Create Model Package and User Entity

- **Folder Structure**:
  - Created a new folder (package)  called 'model' at:
    ```src/main/java/com/lendrix/authservice/model```

- **Tool Used**: VS Code (Linux Mint 21.3)

- **File**: 'User.java'
```
   package com.lendrix.authservice.model;

   import jakarta.persistence.Column;
   import jakarta.persistence.Entity;
   import jakarta.persistence.GeneratedValue;
   import jakarta.persistence.GenerationType;
   import jakarta.persistence.Id;
   import jakarta.persistence.Table;
   import lombok.AllArgsConstructor;
   import lombok.Builder;
   import lombok.Data;
   import lombok.NoArgsConstructor;

   /**
    * Represents a user entity in the authentication service.
    * <p>
    * This class is mapped to the "users" table in the database using JPA annotations.
    * It contains basic user information such as username and password.
    * Lombok annotations are used to generate boilerplate code like getters, setters,
    * constructors, and builder pattern implementation.
    * </p>
    * 
    * <p><b>Database Table:</b> users</p>
    * 
    * <p><b>Fields:</b></p>
    * <ul>
    *   <li><b>id</b> - Primary key, auto-generated unique identifier for the user.</li>
    *   <li><b>username</b> - Unique username, cannot be null.</li>
    *   <li><b>password</b> - Password for authentication, cannot be null.</li>
    * </ul>
    * 
    * <p>Additional fields such as email, roles, etc., can be added as needed.</p>
    * 
    * @author: Dorsphil Osei
    *          dorsphilloseiasuming@gmail.com
    * 
    * @date:   21 May, 2025
    */

    @Entity
    @Table(name = "users")
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public class User {

    /**
     * Unique identifier for the user.
     * This is the primary key and is generated automatically by the database.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Full name of the user.
     * This field cannot be null.
     */
    @Column(nullable = false)
    private String fullName;

    /**
     * email of the user.
     * This must be unique and cannot be null.
     */
    @Column(nullable = false, unique = true)
    private String email;

    /**
     * Password of the user.
     * This field cannot be null.
     */
    @Column(nullable = false)
    private String password;

    // TODO: add Google sign-in info or roles later as needed
  }
```


- **Purpose**:
  - This package holds all the domain model classes for the 'auth-service'.
  - The 'User' entity represents users in our authentication system.

## Step 6:  Create UserRepository Interface

**Package created**
com.lendrix.authservice.repository

**File created**
UserRepository.java

```/**
    * Repository interface for managing {@link com.lendrix.authservice.entity.User} entities.
    * <p>
    * Extends {@link org.springframework.data.jpa.repository.JpaRepository} to provide standard CRUD operations,
    * pagination, and sorting for User entities with a primary key of type {@link Long}.
    * </p>
    * <p>
    * Additionally, declares a method to find a User by their email address.
    * Spring Data JPA will automatically implement this method based on the method name.
    * </p>
    * 
    * <p><b>Usage example:</b></p>
    * <pre>
    * {@code
    * Optional<User> user = userRepository.findByEmail("user@example.com");
    * }
    * </pre>
    * 
    * @see org.springframework.data.jpa.repository.JpaRepository
    * @see com.lendrix.authservice.model.User
    */
      package com.lendrix.authservice.repository;

      import com.lendrix.authservice.model.User;
      import org.springframework.data.jpa.repository.JpaRepository;
      import java.util.Optional;

      public interface UserRepository extends JpaRepository<User, Long> {

          /**
          * Retrieves a user by their email address.
          *
          * @param email the email address to search for
          * @return an {@link Optional} containing the User if found, or empty if not found
          */
          Optional<User> findByEmail(String email);
    }

```

## Notes 
- JpaRepository provides default CRUD methods out of the box.(Create, Read, Update, Delete)
- The custom method findByEmail(String email) will allow the application to fetch 
  users by their email address, which is important during authentication.
- No additional configuration was needed at this stage.


## Step 7:  AuthController and Supporting Layers

**Layers**
1. AuthRequest.java – DTO for login/register
2. AuthResponse.java – DTO for response
3. AuthService.java – Service layer (handles logic)
4. AuthController.java – REST API controller
5. SecurityConfig.java – Basic config (to disable security temporarily for testing)

**A**. **Create AuthRequest.java**

src/main/java/com/lendrix/authservice/dto/AuthRequest.java

```
/**
 * Data Transfer Object (DTO) for authentication requests.
 * <p>
 * This class encapsulates the data required for login or registration operations,
 * specifically the user's email and password.
 * It is used to transfer authentication data between client and server layers,
 * without exposing any business logic.
 * </p>
 * <p>
 * Typical usage includes receiving JSON request bodies in REST APIs and mapping them to this DTO.
 * </p>
 * 
 * <p><b>Fields:</b></p>
 * <ul>
 *   <li><b>email</b> - The user's email address used as the login identifier.</li>
 *   <li><b>password</b> - The user's password for authentication.</li>
 * </ul>
 * 
 * <p>This class provides constructors for easy instantiation, as well as standard getters and setters.</p>
 * 
 * @author  Dorsphil Osei
 *          dorsphilloseiasuming@gmail.com
 * 
 */
package com.lendrix.authservice.dto;

public class AuthRequest {

    /**
     * The email address of the user.
     */
    private String email;

    /**
     * The password of the user.
     */
    private String password;

    /** 
     * The full name of the user
    */
    private String fullName;

    /**
     * Default no-argument constructor.
     */
    public AuthRequest() {}

    /**
     * Constructs an AuthRequest with the specified email and password.
     * 
     * @param email the user's email address
     * @param password the user's password
     */
    public AuthRequest(String email, String password, String fullName) {
        this.email = email;
        this.password = password;
        this.fullName = fullName;
    }

    /**
     * Returns the user's email address.
     * 
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the user's email address.
     * 
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns the user's password.
     * 
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the user's password.
     * 
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

     /**
     * Returns the user's full name
     * 
     * @return the fullName
     */
    public String getfullName() {
        return fullName;
    }

    /**
     * Sets the user's email address.
     * 
     * @param email the email to set
     */
    public void setfullName(String fullName) {
        this.fullName = fullName;
    }

}
```

**B**. **Create AuthResponse.java**

src/main/java/com/lendrix/authservice/dto/AuthResponse.java

```
/**
 * Data Transfer Object (DTO) for authentication responses.
 * <p>
 * This class encapsulates the response message returned after an authentication operation,
 * such as login or registration.
 * It is used to transfer response data from the server to the client,
 * typically in REST API responses.
 * </p>
 * 
 * <p><b>Fields:</b></p>
 * <ul>
 *   <li><b>message</b> - A textual message indicating the result of the authentication request,
 *   such as success or error information.</li>
 * </ul>
 * 
 * <p>This class provides constructors for easy instantiation, as well as standard getters and setters.</p>
 * 
 * @author: Dorsphil Osei
 *          dorsphilloseiasuming@gmail.com
 */
package com.lendrix.authservice.dto;

public class AuthResponse {

    /**
     * The response message indicating the outcome of an authentication request.
     */
    private String message;

    /**
     * Default no-argument constructor.
     */
    public AuthResponse() {}

    /**
     * Constructs an AuthResponse with the specified message.
     * 
     * @param message the response message
     */
    public AuthResponse(String message) {
        this.message = message;
    }

    /**
     * Returns the response message.
     * 
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the response message.
     * 
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
```

**C**. **Create AuthService.java**

src/main/java/com/lendrix/authservice/service/AuthService.java

```
package com.lendrix.authservice.service;

import com.lendrix.authservice.model.User;
import com.lendrix.authservice.repository.UserRepository;
import com.lendrix.authservice.dto.AuthRequest;
import com.lendrix.authservice.dto.AuthResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service class responsible for handling authentication-related operations
 * such as user registration and login.
 * <p>
 * This service interacts with the {@link UserRepository} to perform database operations
 * related to {@link User} entities and processes {@link AuthRequest} DTOs to generate
 * appropriate {@link AuthResponse} DTOs.
 * </p>
 * <p>
 * Note: Passwords are currently handled in plain text for simplicity.
 * In a production environment, passwords should be securely hashed and salted.
 * </p>
 * 
 * @author  Dorsphil Osei
 *          dorsphilloseiasuming@gmail.com
 */
@Service
public class AuthService {

    /**
     * Repository for accessing and managing user data.
     */
    @Autowired
    private UserRepository userRepository;

    /**
     * Registers a new user based on the provided authentication request.
     * <p>
     * Checks if a user with the given email already exists.
     * If so, returns a response indicating the user already exists.
     * Otherwise, creates and saves a new user with the provided email and password.
     * </p>
     * 
     * @param request the authentication request containing user email and password
     * @return an {@link AuthResponse} indicating success or failure of registration
     */
    public AuthResponse register(AuthRequest request) {
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            return new AuthResponse("User already exists");
        }

        User newUser = new User(request.getEmail(), request.getPassword(), request.getfullName()); // for now, password is plain text
        userRepository.save(newUser);
        return new AuthResponse("User registered successfully");

    }

    /**
     * Attempts to log in a user based on the provided authentication request.
     * <p>
     * Searches for a user by email. If found, compares the stored password with the provided password.
     * Returns an appropriate response indicating success, invalid password, or user not found.
     * </p>
     * 
     * @param request the authentication request containing user email and password
     * @return an {@link AuthResponse} indicating success or failure of login
     */
    public AuthResponse login(AuthRequest request) {
        return userRepository.findByEmail(request.getEmail())
                .map(user -> {
                    if (user.getPassword().equals(request.getPassword())) {
                        return new AuthResponse("Login successful");
                    } else {
                        return new AuthResponse("Invalid password");
                    }
                })
                .orElse(new AuthResponse("User not found"));
    }
}
```

**D**. **Create AuthController.java**

src/main/java/com/lendrix/authservice/controller/AuthController.java

```
package com.lendrix.authservice.controller;

import com.lendrix.authservice.dto.AuthRequest;
import com.lendrix.authservice.dto.AuthResponse;
import com.lendrix.authservice.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for handling authentication-related requests.
 * <p>
 * This controller exposes endpoints for user registration and login.
 * It receives {@link AuthRequest} DTOs in the request body,
 * delegates the authentication logic to the {@link AuthService},
 * and returns {@link AuthResponse} DTOs.
 * </p>
 * 
 * @author: Dorsphil Osei
 *          dorsphilloseiasuming@gmail.com
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {
    

    /**
     * Service responsible for handling authentication logic.
     */
    @Autowired
    private AuthService authService;

    /**
     * Endpoint for user registration.
     * <p>
     * Receives an {@link AuthRequest} containing the user's registration details
     * and returns an {@link AuthResponse} indicating the result of the registration attempt.
     * </p>
     * 
     * @param request the authentication request containing user registration details
     * @return an {@link AuthResponse} indicating success or failure of registration
     */
    @PostMapping("/register")
    public AuthResponse register(@RequestBody AuthRequest request) {
        return authService.register(request);
    }


    /**
     * Endpoint for user login.
     * <p>
     * Receives an {@link AuthRequest} containing the user's login credentials
     * and returns an {@link AuthResponse} indicating the result of the login attempt.
     * </p>
     * 
     * @param request the authentication request containing user login credentials
     * @return an {@link AuthResponse} indicating success or failure of login
     */
    @PostMapping("/login")
    public AuthResponse login(@RequestBody AuthRequest request) {
        return authService.login(request);
    }

    
}
```
**E**. **Create SecurityConfig.java to Temporarily Disable Spring Security**

src/main/java/com/lendrix/authservice/config/SecurityConfig.java

```
package com.lendrix.authservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Security configuration class for the authentication service.
 * <p>
 * Configures the Spring Security filter chain for HTTP requests.
 * Currently, CSRF protection is disabled and all HTTP requests are permitted without authentication.
 * </p>
 * <p>
 * This configuration is typically used during development or for services that do not require authentication.
 * For production, you should customize this configuration to enforce security policies.
 * </p>
 * 
 * @author: Dorsphil Osei
 *          dorsphilloseiasuming@gmail.com
 */
@Configuration
public class SecurityConfig {

    /**
     * Defines the security filter chain bean.
     * <p>
     * Disables CSRF protection and allows all HTTP requests without authentication.
     * </p>
     * 
     * @param http the {@link HttpSecurity} to configure
     * @return the configured {@link SecurityFilterChain}
     * @throws Exception if an error occurs during configuration
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(auth -> auth.anyRequest().permitAll()).csrf(csrf -> csrf.disable());
        return http.build();
}

}

```
**NB: The following register and login tests were just demos to test the progress so far.**
      **Find below, the full process involving these functions.**    

**F**. **Run App**
```bash
./mvnw spring-boot:run
```

**G**. **Test Register Option using Postman**

```bash
POST http://localhost:8081/api/auth/register
Content-Type: application/json

{
  "email": "test@lendrix.com",
  "password": "password123"
}
```

**H**. **Test Login Option using Postman or curl**
```bash
POST http://localhost:8081/api/auth/login
Content-Type: application/json

{
  "email": "test@lendrix.com",
  "password": "password123"
}
```

## USER REGISTRATION PROCESS
**What happens:**

- User provides email.

- Backend sends email with confirmation link.

- Starts 2-minute timer before resend link is enabled.

** Code additions/edits:**

- Update AuthController with new endpoint: POST /register/initiate

- Create service method to:

- Generate a token

- Store it with expiry (use Redis or DB with TTL)

- Send email with confirmation link using MailSender

**New or updated files:**

- EmailConfirmationToken.java (Entity)

- EmailService.java

- AuthService.java → add initiateRegistration()


2. User Clicks Email Link → App Opens & Shows Account Type Selection
**What happens:**

- Link opens app (simulate in web as POST /register/confirm?token=xxx)

- User picks account type (e.g., Personal or Business)

 **Code additions/edits:**

- New controller: EmailVerificationController

- Add endpoint GET /register/confirm?token=...

- Validate token, set email as verified, return status

- Update User.java entity: boolean emailVerified

3. User Selects Account Type
**What happens:**

- Backend records selected type for that user

**Code additions:**

- Add accountType field in User.java

- Endpoint POST /register/account-type to save selection

**Files:**

- AccountTypeRequest.java (DTO)

- AuthService.java → method saveAccountType

4. Phone Number Verification (Send SMS & Validate)
**What happens:**

- User enters phone number
- SMS with code sent
- 2-minute resend timer
- User submits code to confirm

**Code additions:**
- Use a mock or Twilio for SMS

- Store verification code with expiry

- Add phoneNumber, phoneVerified to User.java

***Endpoints:**

- POST /register/phone/initiate

- POST /register/phone/verify

**Files:**

- PhoneVerificationService.java

- PhoneVerificationCode.java (Entity or simple Map)

5. User Creates Password
**What happens:**

 - User sets password

- Completes registration

**Code additions:**

-Update existing password field after all verifications

- Endpoint: POST /register/finalize

Files:

- PasswordRequest.java

- AuthService.java → finalizeRegistration()


## Step 1:  Email Entry + Confirmation Link with Timer

- Feature Description:

    - When a user enters an email on the /register route, the app should:
    - Save a temporary user with email only.
    - Generate an email verification token (valid for 2–5 minutes).
    - Send a verification email with a clickable link (e.g., http://localhost:8081/api/auth/verify-email?token=...).
    - On the frontend, enable the resend link button only after 2 minutes.

## A. Update User Entity 

```
    java
        /**
         * Indicates whether the user's email address has been verified.
         * <p>
         * The default value is {@code false}, meaning the email is not verified.
         * This flag should be set to {@code true} after the user successfully completes the email verification process.
         * </p>
         */

            private boolean emailVerified = false;
```

## B. Create VerificationToken Entity
    src/main/java/com/lendrix/authservice/model/VerificationToken.java
```
    java
        /**
         * Represents a verification token used to verify a user's email address.
         */

        @Entity
        public class VerificationToken {

            /**
            * Unique identifier for the token.
            */
            @Id
            @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;

            /**
            * The token string.
            */
            private String token;

            /**
            * The user associated with this token.
            */
            @OneToOne(targetEntity = User.class, fetch = FetchType.EAGER)
            private User user;

            /**
            * The date and time when the token expires.
            */
            private LocalDateTime expiryDate;
        }
```

##  C. Create VerificationTokenRepository
    src/main/java/com/lendrix/authservice/repository/VerificationTokenRepository.java

``` 
    java
        /**
         * Repository interface for managing VerificationToken entities.
         * Provides methods to perform CRUD operations and to find a token by its string value.
         */

        public interface VerificationTokenRepository extends JpaRepository<VerificationToken, Long> {

            /**
            * Finds a VerificationToken entity by its token string.
            *
            * @param token the token string to search for
            * @return an Optional containing the VerificationToken if found, or empty if not found
            */

            Optional<VerificationToken> findByToken(String token);
        }
```

## D. Create EmailService
    src/main/java/com/lendrix/authservice/service/EmailService.java

```
    java
        /**
         * Service for sending emails to users.
         */

        @Service
        public class EmailService {

            @Autowired
            private JavaMailSender mailSender;

            /**
            * Sends a verification email to the specified user with a token link.
            *
            * @param user  the user to send the email to
            * @param token the verification token to include in the email
            */

            public void sendVerificationEmail(User user, String token) {
                String url = "http://localhost:8081/api/auth/verify-email?token=" + token;
                SimpleMailMessage message = new SimpleMailMessage();
                message.setTo(user.getEmail());
                message.setSubject("Verify your email");
                message.setText("Click this link to verify your email: " + url);
                mailSender.send(message);
            }
        }
```

## E. Update Registration Logic (AuthService.java)

```
    java
        /**
         * Registers a new user with the provided email and sends a verification token.
         * <p>
         * This method creates a user with the email from the request, marks the email as unverified,
         * generates a verification token that expires in 2 minutes, saves the token,
         * and sends a verification email to the user.
         * </p>
         *
         * @param request the registration request containing the user's email
         */
        public void register(RegisterRequest request) {

            // Save user with email only
            User user = new User();
            user.setEmail(request.getEmail());
            user.setEmailVerified(false);
            userRepository.save(user);

            // Generate token
            String token = UUID.randomUUID().toString();

            VerificationToken verificationToken = new VerificationToken();
            verificationToken.setToken(token);
            verificationToken.setUser(user);
            verificationToken.setExpiryDate(LocalDateTime.now().plusMinutes(2)); // 2 minutes expiry
            tokenRepository.save(verificationToken);

            // Send email
            emailService.sendVerificationEmail(user, token);
        }
```

##  F. Email Verification Endpoint (AuthController.java)

```
    java
        /**
         * Verifies a user's email using the provided token.
         * <p>
         * Checks if the token exists and is not expired. If valid, marks the user's email as verified.
         * Returns an appropriate response message based on the verification result.
         * </p>
         *
         * @param token the verification token sent to the user's email
         * @return a ResponseEntity with a success message if verified, or an error message if invalid or expired
         */
        @GetMapping("/verify-email")
        public ResponseEntity<String> verifyEmail(@RequestParam("token") String token) {
            Optional<VerificationToken> optional = tokenRepository.findByToken(token);
            if (optional.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid token.");
            }

            VerificationToken verificationToken = optional.get();

            if (verificationToken.getExpiryDate().isBefore(LocalDateTime.now())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Token expired.");
            }

            User user = verificationToken.getUser();
            user.setEmailVerified(true);
            userRepository.save(user);

            return ResponseEntity.ok("Email verified. You can now continue registration.");
        }
```

##  G. Add Dependencies (in pom.xml)

```
    xml
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-mail</artifactId>
        </dependency>show me all the postman tests we have done so far for the registration flow process we did aboe. i want to document that bit . so the post man tests for thes . User Enters Email → Send Confirmation Link
```

## H. Configuration (application.properties)

```
    spring.mail.host=smtp.gmail.com
    spring.mail.port=587
    spring.mail.username=lendrixapp@gmail.com
    spring.mail.password=kdfwfgljowyxkvek # ← This is the App Password with no spaces!
    spring.mail.properties.mail.smtp.auth=true
    spring.mail.properties.mail.smtp.starttls.enable=true
```
## POSTMAN TEST

*Endpoint:*
* POST /api/auth/register/initiate

Purpose:
Trigger sending of email confirmation link with token and 2-minute cooldown before resend.

🔸 Request Body:
```
    json
        {
    "email": "testuser@example.com"
    }
```
*Expected Result:*
- 200 OK

- Email is sent with confirmation link (check logs or mock inbox)

- VerificationToken stored in DB


##  Step 2:  Email Link Confirmation → Show Account Type Selection

## Feature Description:
-   When the user clicks the email verification link (e.g., from http://localhost:8081/api/auth/verify-email?token=...), 
    the backend should:

1. Validate the token.

2. Controller looks up token using VerificationTokenRepository

3. Token is validated (exists, not expired)

4. If valid, User.emailVerified = true is set

5. Mark the email as verified.

6. Changes are persisted using UserRepository.save(...)

7. Frontend receives HTTP 200 and proceeds to next screen

8. Respond with a status (email verified) so the frontend can show account type selection (Personal or Business).



## A. Create EmailVerificationController.java
   src/main/java/com/lendrix/authservice/controller/EmailVerificationController.java
```
    java
        /**
         * Controller for handling email verification confirmation links during user registration.
         * <p>
         * This controller provides an endpoint that is triggered when a user clicks the verification
         * link sent to their email. It validates the token, checks for expiration, and if valid,
         * marks the user's email as verified in the system.
         * </p>
         * <p>
         * The verification token is retrieved from the database using the {@link VerificationTokenRepository}.
         * Upon successful verification, the user's status is updated via the {@link UserRepository}.
         * </p>
         * <p>
         * Typical usage involves the user receiving an email with a link containing the token as a query parameter.
         * When the link is accessed, this controller processes the token and responds with a success or error message.
         * </p>
         * 
         * <p><b>Endpoint:</b> <code>GET /api/auth/register/confirm?token=...</code></p>
         * 
         * <p><b>Responses:</b></p>
         * <ul>
         *   <li><b>200 OK:</b> Email successfully verified, user can proceed with registration.</li>
         *   <li><b>400 Bad Request:</b> Token is invalid or expired.</li>
         * </ul>
         * 
         * @author: Dorsphil Osei Asuming Animwaa
                    dorsphilloseiasuming@gmail.com
         * @since 1.0
         */
        @RestController
        @RequestMapping("/api/auth")
        public class EmailVerificationController {

            @Autowired
            private VerificationTokenRepository tokenRepository;

            @Autowired
            private UserRepository userRepository;

            /**
            * Endpoint triggered when the user clicks the email verification link.
            * <p>
            * This method checks if the token exists and is valid (not expired). If valid,
            * it sets the user's emailVerified flag to true and saves the user.
            * </p>
            * 
            * @param token The verification token from the email URL
            * @return ResponseEntity with status message indicating success or failure
            */
            @GetMapping("/register/confirm")
            public ResponseEntity<String> confirmEmail(@RequestParam("token") String token) {
                Optional<VerificationToken> optional = tokenRepository.findByToken(token);
                if (optional.isEmpty()) {
                    return ResponseEntity.badRequest().body("Invalid or missing token.");
                }

                VerificationToken verificationToken = optional.get();

                if (verificationToken.getExpiryDate().isBefore(LocalDateTime.now())) {
                    return ResponseEntity.badRequest().body("Token has expired.");
                }

                User user = verificationToken.getUser();
                user.setEmailVerified(true);
                userRepository.save(user);

                return ResponseEntity.ok("Email verified. Please select your account type.");
            }
        }
```
## B. Create a Verification Token file.
src/main/java/com/lendrix/authservice/model/VerificationToken.java

``` 
        package com.lendrix.authservice.model;

        import java.time.LocalDateTime;

        import jakarta.persistence.Entity;
        import jakarta.persistence.Id;
        import jakarta.persistence.GeneratedValue;
        import jakarta.persistence.GenerationType;
        import jakarta.persistence.OneToOne;
        import jakarta.persistence.FetchType;

        import lombok.Data;
        import lombok.NoArgsConstructor;
        import lombok.AllArgsConstructor;

        /**
        * Entity representing a verification token used for user account verification processes,
        * such as email confirmation or password reset.
        *
        * <p>
        * Each token is associated with a specific {@link User} and has an expiry date.
        * </p>
        * 
        * @author: Dorsphil Osei
        *          dorsphillloseiasuming@gmail.com
        */
        @Data
        @NoArgsConstructor
        @AllArgsConstructor
        @Entity
        public class VerificationToken {

            /**
            * Unique identifier for the verification token.
            */
            @Id
            @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;

            /**
            * The token string used for verification.
            */
            private String token;

            /**
            * The user associated with this verification token.
            */
            @OneToOne(targetEntity = User.class, fetch = FetchType.EAGER)
            private User user;

            /**
            * The date and time when the token expires.
            */
            private LocalDateTime expiryDate;

            // Getters, setters, constructors, and other methods omitted for brevity.
        }
```

##  C. Create a Verification Token  Repository file.
src/main/java/com/lendrix/authservice/repository/VerificationTokenRepository.java

```
    package com.lendrix.authservice.repository;

    // JPA repository for CRUD operations
    import org.springframework.data.jpa.repository.JpaRepository;

    // Optional container for nullable return values
    import java.util.Optional;

    // VerificationToken entity
    import com.lendrix.authservice.model.VerificationToken;

    /**
    * Repository interface for managing VerificationToken entities.
    * Extends JpaRepository to provide CRUD and custom finder methods.
    * 
    * @author  Dorsphil Osei
    *          dorsphillloseiasuming@gmail.com
    */
    public interface VerificationTokenRepository extends JpaRepository<VerificationToken, Long> {

        /**
        * Find a VerificationToken by its token string.
        *
        * @param token the verification token string
        * @return Optional containing the VerificationToken if found, or empty otherwise
        */
        Optional<VerificationToken> findByToken(String token);
    }

```

## D. Update User.java
src/main/java/com/lendrix/authservice/model/User.java
```
    /**
     * Entity representing a registered user.
     *
     * Includes fields like emailVerified to track registration progress.
     */
    @Entity
    public class User {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @Column(nullable = false, unique = true)
        private String email;

        @Column(nullable = false)
        private boolean emailVerified = false;

        // Other fields and methods omitted for brevity

        public boolean isEmailVerified() {
            return emailVerified;
        }

        public void setEmailVerified(boolean emailVerified) {
            this.emailVerified = emailVerified;
        }
    }
```
## POSTMAN TEST

*Endpoint:*
- GET /api/auth/register/confirm?token=<token>

 Purpose:
- Verify the email using the token and update emailVerified = true.

🔸 Sample Request:
```
    GET /api/auth/register/confirm?token=7f3a62b1-1234-4c9a-b5af-34215abc123f
```
*Expected Result:*
- 200 OK
- Response body: "Email verified successfully."
- User's emailVerified field set to true


##  Spring Boot Startup Errors - Reference Guide

## Error 1: Missing PasswordEncoder Bean

**Error Message:**
```
NoSuchBeanDefinitionException: No qualifying bean of type 'org.springframework.security.crypto.password.PasswordEncoder' available
```

**Cause:**
- `AuthService` class had `@Autowired PasswordEncoder` but no `PasswordEncoder` bean was defined in the Spring context
- Spring Security requires a `PasswordEncoder` bean when using password-based authentication

**Solution:**
Added `PasswordEncoder` bean to existing `SecurityConfig` class:
```java
@Bean
public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
}
```

---

## Error 2: Mail Server Connection Failure

**Error Message:**
```
IllegalStateException: Mail server is not available
MailConnectException: Couldn't connect to host, port: smtp.gmail.com, 587
```

**Cause:**
- Spring Boot's mail auto-configuration was trying to validate SMTP connection on startup
- `spring.mail.test-connection=true` was set in `application.properties`
- Connection to Gmail SMTP server failed (network/firewall/credentials issues)

**Solution:**
Changed configuration in `application.properties`:
```properties
# Disable mail connection testing on startup
spring.mail.test-connection=false
```

**Alternative Solutions:**
1. Remove mail dependencies if email functionality not needed
2. Exclude mail auto-configuration: `@SpringBootApplication(exclude = {MailSenderAutoConfiguration.class})`
3. Fix network/credential issues for proper SMTP connection

---

## Key Takeaways

1. **Missing Bean Dependencies:** Always ensure required beans are defined when using `@Autowired`
2. **Mail Configuration:** Disable connection testing during development to avoid startup failures
3. **Security Configuration:** `PasswordEncoder` is mandatory when using Spring Security with passwords
4. **Environment Separation:** Consider using profiles for different mail settings (dev vs prod)

---

## Best Practices

- Use `BCryptPasswordEncoder` for production password hashing
- Store sensitive credentials in environment variables
- Disable unnecessary connection testing in development environments
- Keep mail configuration separate for different environments


## Step 3: Account Type Selection (Personal / Business)

## Feature Description:
- After a user successfully verifies their email, they are prompted to select the type of account they wish to create:
    1. Personal
    2. Business
This account type is stored in the backend and used to customize the user’s experience.

## Key Functional Requirements:
- Add a new field accountType to the User entity.
- Create a DTO to receive the selected account type from the frontend.
- Implement a saveAccountType method in the AuthService.
- Expose a POST /api/auth/register/account-type endpoint in the controller.
- Validate the request and update the user’s record in the database.

## A. Updated Entity: User.java
src/main/java/com/lendrix/authservice/model/User.java

```
    /**
     * Entity representing a user in the Lendrix system.
     * Extended to support account type selection.
     */
    @Entity
    @Table(name = "users")
    public class User {

        // other fields...

        
        /**
         * The type of user account: "Personal" or "Business".
         */
        private String accountType; 
    }

```

## B. Create a DTO File: AccountTypeRequest.java
src/main/java/com/lendrix/authservice/dto/AccountTypeRequest.java

```
    package com.lendrix.authservice.dto;

    import lombok.Data;

    /**
     * DTO representing a request to set the account type for a user.
     */
    @Data
    public class AccountTypeRequest {
        private String email;
        private String accountType;  // Expected values: "Personal" or "Business"
    }
```


## C. Updated Service: AuthService.java
src/main/java/com/lendrix/authservice/service/AuthService.java

```
    /**
     * Handles business logic for authentication and registration.
     */
    @Service
    public class AuthService {

        @Autowired
        private UserRepository userRepository;

        /**
         * Saves the selected account type for the user.
         *
         * @param request AccountTypeRequest object containing account type and user ID
         * @return A confirmation message
         * @throws IllegalArgumentException if user is not found
         */
        public String saveAccountType(AccountTypeRequest request) {
            User user = userRepository.findById(request.getUserId())
                    .orElseThrow(() -> new IllegalArgumentException("User not found"));

            user.setAccountType(request.getAccountType());
            userRepository.save(user);

            return "Account type saved successfully.";
        }
    }
```

## D.  Updated Controller: AuthController.java
src/main/java/com/lendrix/authservice/controller/AuthController.java

```
    /**
     * Controller for managing authentication and registration-related endpoints.
     */
    @RestController
    @RequestMapping("/api/auth")
    public class AuthController {

        @Autowired private AuthService authService;

        /**
        * Endpoint to save the user's account type after email verification.
        * 
        * <p><b>Endpoint:</b> <code>POST /api/auth/register/account-type</code></p>
        * 
        * <p><b>Request Body:</b></p>
        * <pre>{
        *     "userId": 1,
        *     "accountType": "PERSONAL"
        * }</pre>
        * 
        * <p><b>Responses:</b></p>
        * <ul>
        *   <li><b>200 OK:</b> Account type saved successfully.</li>
        *   <li><b>400 Bad Request:</b> User not found or invalid input.</li>
        * </ul>
        *
        * @param request DTO containing user ID and selected account type
        * @return ResponseEntity with status and message
        */
        @PostMapping("/register/account-type")
        public ResponseEntity<String> saveAccountType(@RequestBody @Valid AccountTypeRequest request) {
            try {
                String message = authService.saveAccountType(request);
                return ResponseEntity.ok(message);
            } catch (IllegalArgumentException e) {
                return ResponseEntity.badRequest().body(e.getMessage());
            }
        }
    }
```
## POSTMAN TEST

*Endpoint:*
- POST /api/auth/register/account-type

*Purpose:*
- Set the account type (e.g., Personal or Business) after email is verified.

🔸 Request Body:
```
    json
        {
        "email": "testuser@example.com",
        "accountType": "PERSONAL"
    }
```
*Expected Result:*
- 200 OK
- User's accountType field updated in DB


## Step 4: Phone Number / SMS Verification
🔹 Objective
- Allow users to:
1. Submit their email and phone number to initiate SMS code verification.
2. Enter the received SMS code to verify their phone number.
3. Ensure codes expire after 2 minutes and cannot be reused.

## A. Create DTO PhoneVerificationRequest.java
src/main/java/com/lendrix/authservice/dto/PhoneVerificationRequest.java

Purpose: Used in the POST /register/phone/initiate endpoint.

```
    package com.lendrix.authservice.dto;

    import lombok.Data;

    /**
    * Data Transfer Object (DTO) representing a request to initiate phone verification.
    * <p>
    * This class contains the user's email and phone number that are required
    * to start the phone verification process.
    * </p>
    * 
    * <ul>
    *   <li><b>email:</b> The email address of the user requesting verification.</li>
    *   <li><b>phoneNumber:</b> The phone number to be verified.</li>
    * </ul>
    * 
    * This DTO is typically used as the request body in API calls.
    */
    @Data
    public class PhoneVerificationRequest {
        /**
        * The email address of the user.
        */
        private String email;

        /**
        * The phone number to verify.
        */
        private String phoneNumber;
    }
```
## B. Create DTO PhoneCodeVerificationRequest.java
src/main/java/com/lendrix/authservice/dto/PhoneCodeVerificationRequest.java

 Purpose: Used in the POST /register/phone/verify endpoint.

```
    package com.lendrix.authservice.dto;

    import lombok.Data;

    /**
    * Data Transfer Object (DTO) representing a request to verify a phone code.
    * <p>
    * This class contains the user's email and the verification code that the user submits
    * to confirm their phone number.
    * </p>
    * 
    * <ul>
    *   <li><b>email:</b> The email address of the user attempting verification.</li>
    *   <li><b>code:</b> The verification code received by the user on their phone.</li>
    * </ul>
    * 
    * This DTO is typically used as the request body in API calls for phone code verification.
    */
    @Data
    public class PhoneCodeVerificationRequest {
        /**
        * The email address of the user.
        */
        private String email;

        /**
        * The verification code sent to the user's phone.
        */
        private String code;
    }
```

## C. Created Entity file PhoneVerificationCode.java
src/main/java/com/lendrix/authservice/model/PhoneVerificationCode.java

Purpose: Stores a code, expiry time, and user-phone mapping.

```
    package com.lendrix.authservice.model;

    import jakarta.persistence.*;
    import lombok.Data;

    import java.time.LocalDateTime;

    /**
     * Represents a phone verification code entity used for verifying a user's phone number.
     * <p>
     * This entity stores the verification code sent to a user's phone, the phone number,
     * the expiration time of the code, and the associated user.
     * </p>
     * <p>
     * It is mapped to a database table using JPA annotations.
     * </p>
     * 
     * <ul>
     *   <li><b>id:</b> Unique identifier for each verification code (auto-generated).</li>
     *   <li><b>phoneNumber:</b> The phone number to which the verification code was sent.</li>
     *   <li><b>code:</b> The actual verification code sent to the user.</li>
     *   <li><b>expiryTime:</b> The date and time when the verification code expires and becomes invalid.</li>
     *   <li><b>user:</b> The user associated with this verification code (one-to-one relationship).</li>
     * </ul>
     * 
     * @see User
     */
    @Entity
    @Data
    public class PhoneVerificationCode {

        /**
        * The primary key identifier for the phone verification code.
        * This value is automatically generated by the database.
        */
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        /**
        * The phone number to which the verification code was sent.
        */
        private String phoneNumber;

        /**
        * The verification code sent to the user's phone.
        */
        private String code;

        /**
        * The expiration time of the verification code.
        * After this time, the code is no longer valid.
        */
        private LocalDateTime expiryTime;

        /**
        * The user associated with this verification code.
        * There is a one-to-one relationship between a phone verification code and a user.
        */
        @OneToOne
        private User user;
    }
```

## D. Created Repository PhoneVerificationCodeRepository.java
src/main/java/com/lendrix/authservice/repository/PhoneVerificationCodeRepository.java

Purpose: Manages DB operations for PhoneVerificationCode.

```
    package com.lendrix.authservice.repository;

    import com.lendrix.authservice.model.PhoneVerificationCode;
    import org.springframework.data.jpa.repository.JpaRepository;

    import java.util.Optional;

    /**
    * Repository interface for managing {@link PhoneVerificationCode} entities.
    * <p>
    * This interface extends {@link JpaRepository} which provides standard methods
    * for CRUD (Create, Read, Update, Delete) operations on phone verification codes.
    * </p>
    * <p>
    * It also defines a custom method to find a verification code by phone number.
    * </p>
    * 
    * Example usage:
    * <pre>
    *     Optional&lt;PhoneVerificationCode&gt; code = repository.findByPhoneNumber("1234567890");
    * </pre>
    * 
    * @see PhoneVerificationCode
    * @see JpaRepository
    */
    public interface PhoneVerificationCodeRepository extends JpaRepository<PhoneVerificationCode, Long> {

        /**
        * Finds a phone verification code entity by the given phone number.
        *
        * @param phoneNumber the phone number to search for
        * @return an {@link Optional} containing the {@link PhoneVerificationCode} if found,
        *         or an empty {@link Optional} if no code exists for that phone number
        */
        Optional<PhoneVerificationCode> findByPhoneNumber(String phoneNumber);
    }
```

## E. Created PhoneVerificationService.java
src/main/java/com/lendrix/authservice/service/PhoneVerificationService.java

Purpose: Manages logic for generating, storing, and verifying phone codes.

- Method 1: initiateVerification(String email, String phoneNumber)

- Finds the user by email.
- Updates their phone number.
- Generates 6-digit code (random).
- Sets 2-minute expiry.
- Saves in PhoneVerificationCodeRepository.
- Simulates sending SMS (prints to console).

- Method 2: verifyCode(String email, String codeInput)

- Finds user by email.
- Retrieves verification code by phone number.
- Checks code match & if not expired.
- If valid → marks phoneVerified = true, deletes the used code.

```
    package com.lendrix.authservice.service;

import com.lendrix.authservice.model.PhoneVerificationCode;
import com.lendrix.authservice.model.User;
import com.lendrix.authservice.repository.PhoneVerificationCodeRepository;
import com.lendrix.authservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

/**
 * Service responsible for handling phone number verification processes.
 * <p>
 * This service allows initiating a phone verification by generating and sending a verification code,
 * and verifying the code entered by the user.
 * </p>
 * <p>
 * It interacts with {@link UserRepository} and {@link PhoneVerificationCodeRepository} to manage users
 * and their phone verification codes.
 * </p>
 * 
 * <p><b>Usage example:</b></p>
 * <pre>
 *   phoneVerificationService.initiateVerification("user@example.com", "1234567890");
 *   boolean verified = phoneVerificationService.verifyCode("user@example.com", "123456");
 * </pre>
 * 
 * @see User
 * @see PhoneVerificationCode
 * @see UserRepository
 * @see PhoneVerificationCodeRepository
 */
@Service
public class PhoneVerificationService {

    @Autowired
    private PhoneVerificationCodeRepository codeRepository;

    @Autowired
    private UserRepository userRepository;

    /**
     * Starts the phone verification process for a user identified by their email.
     * <p>
     * This method:
     * <ul>
     *   <li>Finds the user by email.</li>
     *   <li>Updates the user's phone number.</li>
     *   <li>Generates a random 6-digit verification code.</li>
     *   <li>Sets an expiry time for the code (2 minutes from now).</li>
     *   <li>Saves the verification code linked to the user.</li>
     *   <li>Simulates sending the code via SMS (prints to console).</li>
     * </ul>
     * 
     * @param email the email of the user to verify the phone number for
     * @param phoneNumber the phone number to verify
     * @throws RuntimeException if no user is found with the given email
     */
    public void initiateVerification(String email, String phoneNumber) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        if (optionalUser.isEmpty()) throw new RuntimeException("User not found");

        User user = optionalUser.get();
        user.setPhoneNumber(phoneNumber);
        userRepository.save(user);

        String code = String.valueOf(100000 + new Random().nextInt(900000)); // 6-digit code
        LocalDateTime expiry = LocalDateTime.now().plusMinutes(2);

        PhoneVerificationCode pvc = new PhoneVerificationCode();
        pvc.setPhoneNumber(phoneNumber);
        pvc.setCode(code);
        pvc.setExpiryTime(expiry);
        pvc.setUser(user);

        codeRepository.save(pvc);

        // Simulate SMS sending (replace with real SMS service like Twilio)
        System.out.println("Sending SMS to " + phoneNumber + ": Your code is " + code);
    }

    /**
     * Verifies the phone verification code entered by the user.
     * <p>
     * This method:
     * <ul>
     *   <li>Finds the user by email.</li>
     *   <li>Retrieves the stored verification code for the user's phone number.</li>
     *   <li>Checks if the input code matches the stored code and if it has not expired.</li>
     *   <li>If valid, marks the user's phone as verified and removes the used code.</li>
     * </ul>
     * 
     * @param email the email of the user attempting verification
     * @param codeInput the verification code entered by the user
     * @return {@code true} if the code is valid and verification succeeds; {@code false} otherwise
     */
    public boolean verifyCode(String email, String codeInput) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        if (optionalUser.isEmpty()) return false;

        User user = optionalUser.get();
        Optional<PhoneVerificationCode> optionalCode = codeRepository.findByPhoneNumber(user.getPhoneNumber());

        if (optionalCode.isPresent()) {
            PhoneVerificationCode pvc = optionalCode.get();
            if (pvc.getCode().equals(codeInput) && pvc.getExpiryTime().isAfter(LocalDateTime.now())) {
                user.setPhoneVerified(true);
                userRepository.save(user);
                codeRepository.delete(pvc); // optional: remove used code
                return true;
            }
        }

        return false;
    }
}
```

## F. Updated User.java
src/main/java/com/lendrix/authservice/model/User.java

* Updates Made:
1. Added phoneNumber field (String)
2. Added phoneVerified field (boolean)

```
    /* the user's phone number for verification*/
    private String phoneNumber;

    
    private boolean phoneVerified;
```
## POSTMAN TEST

*Endpoint:*
- POST /api/auth/register/phone/initiate

Purpose:
- Send an SMS verification code to the user.

🔸 Request Body:
```
    json
    {
        "email": "testuser@example.com",
        "phoneNumber": "+254700000001"
    }
```
 *Expected Result:*
- 200 OK
- SMS log/output shows code sent (mocked)
- Code stored with expiry

🔹 4b. Phone Number Verification – Submit Code

*Endpoint:*
- POST /api/auth/register/phone/verify

Purpose:
Verify the SMS code received by the user.

🔸 Request Body:
```
    json
    {
        "email": "testuser@example.com",
        "code": "123456"
    }
```
*Expected Result:*
- 200 OK
- User's phoneVerified = true in DB



## Step 5:  User Creates Password (Finalize Registration)
- The user sets a password to complete registration.
- Once done, the backend marks registration as complete.

## A. Create PasswordRequest.java
src/main/java/com/lendrix/authservice/dto/PasswordRequest.java

Purpose: Holds email and password values submitted by user in the final registration step.

```
    package com.lendrix.authservice.dto;

    import lombok.Data;

    /**
     * Data Transfer Object (DTO) used for the password creation step during user registration.
     * <p>
     * This class holds the user's email and the password they wish to set.
     * It is typically used in the final stage of the registration process,
     * where the user provides their email and chooses a password.
     * </p>
     *
     * <p>
     * Example usage:
     * <pre>
     *     PasswordRequest request = new PasswordRequest();
     *     request.setEmail("user@example.com");
     *     request.setPassword("securePassword123");
     * </pre>
     * </p>
     *
     * @author [Your Name]
     */
    @Data
    public class PasswordRequest {
        /**
         * The email address of the user registering an account.
         */
        private String email;

        /**
         * The password chosen by the user for their account.
         */
        private String password;
    }
```
## B.  Add finalizeRegistration() to AuthService.java
src/main/java/com/lendrix/authservice/service/AuthService.java

Add this method:
```
    /**
     * Completes the user registration process by setting the user's password.
     * <p>
     * This method assumes that the user's email exists in the system, and that
     * the user's phone number has been verified and an account type has been selected.
     * It performs the following steps:
     * </p>
     * <ul>
     *   <li>Checks if a user with the given email exists; throws an exception if not found.</li>
     *   <li>Verifies that the user's phone number is confirmed; throws an exception if not verified.</li>
     *   <li>Ensures the user has selected an account type; throws an exception if missing.</li>
     *   <li>Sets the provided password for the user (password hashing to be implemented later).</li>
     *   <li>Saves the updated user information to the repository.</li>
     * </ul>
     *
     * @param email    the email address of the user completing registration
     * @param password the password to set for the user account
     * @throws RuntimeException if the user is not found, phone number is not verified, or account type is not selected
     */
    public void finalizeRegistration(String email, String password) {
        Optional<User> optionalUser = userRepository.findByEmail(email);

        if (optionalUser.isEmpty()) {
            throw new RuntimeException("User not found.");
        }

        User user = optionalUser.get();

        if (!user.isPhoneVerified()) {
            throw new RuntimeException("Phone number not verified.");
        }

        if (user.getAccountType() == null) {
            throw new RuntimeException("Account type not selected.");
        }

        user.setPassword(password); // We'll hash this later!
        userRepository.save(user);
    }
```
## POSTMAN TEST

*Endpoint:*
- POST /api/auth/register/finalize

Purpose:
- Set the user’s password and complete registration.

🔸 Request Body:
```
    {
        "email": "testuser@example.com",
        "password": "MySecurePass123!"
    }
```
*Expected Result:*
- 200 OK
- Password saved in DB




## C. Create POST /register/finalize in AuthController.java
src/main/java/com/lendrix/authservice/controller/AuthController.java

Add this endpoint:
```
    /**
     * Final step in registration: user sets their password.
     * 
     * @param request contains email and password
     * @return 200 OK if successful
     */
    @PostMapping("/register/finalize")
    public ResponseEntity<String> finalizeRegistration(@RequestBody PasswordRequest request) {
        authService.finalizeRegistration(request.getEmail(), request.getPassword());
        return ResponseEntity.ok("Registration complete. You may now log in.");
    }
```

## Step 6:  Hashing password

## A. Use BCryptPasswordEncoder from Spring Security
Updated File: AuthService.java
🔹 First, inject the encoder:
```
    import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
    import org.springframework.security.crypto.password.PasswordEncoder;

    @Service
    public class AuthService {

        private final PasswordEncoder passwordEncoder;

        // constructor
        public AuthService(PasswordEncoder passwordEncoder) {
            this.passwordEncoder = passwordEncoder;
        }

        // ... rest of the code
    }
```

## B. PasswordEncoder Bean already existed in Security.config

## C. Hash the password before saving the user
Updated File: AuthService.java
🔹 Inside your finalizeRegistration() method or wherever you're saving the user:
```
    user.setPassword(password);
        String hashedPassword = passwordEncoder.encode(password);
        user.setPassword(hashedPassword);
```

## D.  Confirm user entity saves it
File: User.java
- Just confirm that @Column(name = "password") exists and is of type String.

## POSTMAN TEST
1. Run POST /register/finalize request from Postman
```
    json
        {
            "email": "test@lendrix.com",
            "password": "MySecureP@ssw0rd"
        }
```
2.  - Check the database (SELECT * FROM users)

    - You should see a password starting like:
```
    $2a$10$...
```


 # Notes
- All emails and SMS logs were mocked/tested via console logs for now.

- All passwords are hashed using BCryptPasswordEncoder.

- Each step is isolated so you can test and fix individual parts easily.

- If any field is missing or invalid, you get proper 4xx error codes.


## CORRECTIONS MADE TO THE REGISTRATION FLOW PROCESS
    The existing issues were;

- The /register endpoint creates a full user with password
- The multi-step flow improperly sequenced
- Missing country selection step
- User entity isn't saved properly in the first step
- The flow doesn't prevent users from skipping steps

    **Added a field to User.java to handle country selection by user**
```
    java

    @Column
    private String countryOfResidence;
```
**Temporary storage of registration data between steps**
**Progress tracking through the registration flow**

**UPDATED FILES TO IMPLEMENT CORRECTIONS**
1. AuthController.java
```
    java
        package com.lendrix.authservice.controller;

        import com.lendrix.authservice.dto.AccountTypeRequest;
        import com.lendrix.authservice.dto.AuthRequest;
        import com.lendrix.authservice.dto.AuthResponse;
        import com.lendrix.authservice.dto.CountrySelectionRequest;
        import com.lendrix.authservice.dto.EmailRegistrationRequest;
        import com.lendrix.authservice.dto.PasswordRequest;
        import com.lendrix.authservice.dto.PhoneCodeVerificationRequest;
        import com.lendrix.authservice.dto.PhoneVerificationRequest;
        import com.lendrix.authservice.model.User;
        import com.lendrix.authservice.model.VerificationToken;
        import com.lendrix.authservice.repository.UserRepository;
        import com.lendrix.authservice.repository.VerificationTokenRepository;
        import com.lendrix.authservice.service.AuthService;
        import com.lendrix.authservice.service.PhoneVerificationService;

        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.http.HttpStatus;
        import org.springframework.http.ResponseEntity;
        import org.springframework.web.bind.annotation.*;

        import java.time.LocalDateTime;
        import java.util.Optional;

        /**
        * REST controller for handling multi-step authentication registration.
        * 
        * Registration Flow:
        * 1. POST /api/auth/register/start - Enter email and full name
        * 2. GET /api/auth/verify-email?token=... - Verify email
        * 3. POST /api/auth/register/account-type - Choose account type
        * 4. POST /api/auth/register/country - Choose country of residence
        * 5. POST /api/auth/register/phone/initiate - Start phone verification
        * 6. POST /api/auth/register/phone/verify - Verify phone code
        * 7. POST /api/auth/register/finalize - Set password and complete registration
        * 
        * @author Dorsphil Osei <dorsphillloseiasuming@gmail.com>
        */
        @RestController
        @RequestMapping("/api/auth")
        public class AuthController {

            @Autowired
            private AuthService authService;

            @Autowired
            private VerificationTokenRepository tokenRepository;

            @Autowired
            private UserRepository userRepository;

            @Autowired
            private PhoneVerificationService phoneVerificationService;

            // ============= LEGACY SINGLE-STEP REGISTRATION (Keep for backward compatibility) =============
            
            /**
            * Legacy single-step registration endpoint.
            * @deprecated Use the multi-step registration flow instead
            */
            @PostMapping("/register")
            @Deprecated
            public AuthResponse register(@RequestBody AuthRequest request) {
                return authService.register(request);
            }

            /**
            * Login endpoint
            */
            @PostMapping("/login")
            public AuthResponse login(@RequestBody AuthRequest request) {
                return authService.login(request);
            }

            // ============= MULTI-STEP REGISTRATION FLOW =============

            /**
            * STEP 1: Start registration with email and full name
            * Creates a user record and sends email verification
            */
            @PostMapping("/register/start")
            public ResponseEntity<AuthResponse> startRegistration(@RequestBody EmailRegistrationRequest request) {
                try {
                    AuthResponse response = authService.startRegistration(request);
                    return ResponseEntity.ok(response);
                } catch (RuntimeException e) {
                    return ResponseEntity.badRequest().body(new AuthResponse(e.getMessage()));
                }
            }

            /**
            * STEP 2: Verify email address
            * Validates the email verification token
            */
            @GetMapping("/verify-email")
            public ResponseEntity<String> verifyEmail(@RequestParam("token") String token) {
                Optional<VerificationToken> optional = tokenRepository.findByToken(token);

                if (optional.isEmpty()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid token.");
                }

                VerificationToken verificationToken = optional.get();

                if (verificationToken.getExpiryDate().isBefore(LocalDateTime.now())) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Token expired.");
                }

                User user = verificationToken.getUser();
                user.setEmailVerified(true);
                userRepository.save(user);

                // Clean up the used token
                tokenRepository.delete(verificationToken);

                return ResponseEntity.ok("Email verified successfully. You can now continue with account setup.");
            }

            /**
            * STEP 3: Select account type (Personal or Business)
            * Requires email to be verified
            */
            @PostMapping("/register/account-type")
            public ResponseEntity<AuthResponse> saveAccountType(@RequestBody AccountTypeRequest request) {
                try {
                    AuthResponse response = authService.saveAccountType(request);
                    return ResponseEntity.ok(response);
                } catch (RuntimeException e) {
                    return ResponseEntity.badRequest().body(new AuthResponse(e.getMessage()));
                }
            }

            /**
            * STEP 4: Select country of residence
            * Requires email verification and account type selection
            */
            @PostMapping("/register/country")
            public ResponseEntity<AuthResponse> saveCountryOfResidence(@RequestBody CountrySelectionRequest request) {
                try {
                    AuthResponse response = authService.saveCountryOfResidence(request);
                    return ResponseEntity.ok(response);
                } catch (RuntimeException e) {
                    return ResponseEntity.badRequest().body(new AuthResponse(e.getMessage()));
                }
            }

            /**
            * STEP 5: Initiate phone number verification
            * Requires email verification, account type, and country selection
            */
            @PostMapping("/register/phone/initiate")
            public ResponseEntity<String> initiatePhoneVerification(@RequestBody PhoneVerificationRequest request) {
                try {
                    // Validate prerequisite steps
                    authService.validatePhoneVerificationPrerequisites(request.getEmail());
                    
                    phoneVerificationService.initiateVerification(request.getEmail(), request.getPhoneNumber());
                    return ResponseEntity.ok("Verification code sent to your phone number.");
                } catch (RuntimeException e) {
                    return ResponseEntity.badRequest().body(e.getMessage());
                }
            }

            /**
            * STEP 6: Verify phone number code
            * Validates the SMS code sent to user's phone
            */
            @PostMapping("/register/phone/verify")
            public ResponseEntity<String> verifyPhoneCode(@RequestBody PhoneCodeVerificationRequest request) {
                try {
                    boolean success = phoneVerificationService.verifyCode(request.getEmail(), request.getCode());
                    return success ?
                        ResponseEntity.ok("Phone number verified successfully.") :
                        ResponseEntity.badRequest().body("Invalid or expired verification code.");
                } catch (RuntimeException e) {
                    return ResponseEntity.badRequest().body(e.getMessage());
                }
            }

            /**
            * STEP 7: Finalize registration with password
            * Completes the registration process
            */
            @PostMapping("/register/finalize")
            public ResponseEntity<String> finalizeRegistration(@RequestBody PasswordRequest request) {
                try {
                    authService.finalizeRegistration(request.getEmail(), request.getPassword());
                    return ResponseEntity.ok("Registration completed successfully. You can now login.");
                } catch (RuntimeException e) {
                    return ResponseEntity.badRequest().body(e.getMessage());
                }
            }

            // ============= UTILITY ENDPOINTS =============

            /**
            * Check registration status for a given email
            */
            @GetMapping("/register/status")
            public ResponseEntity<AuthResponse> getRegistrationStatus(@RequestParam("email") String email) {
                try {
                    AuthResponse response = authService.getRegistrationStatus(email);
                    return ResponseEntity.ok(response);
                } catch (RuntimeException e) {
                    return ResponseEntity.badRequest().body(new AuthResponse(e.getMessage()));
                }
            }

            /**
            * Resend email verification token
            */
            @PostMapping("/register/resend-email")
            public ResponseEntity<String> resendEmailVerification(@RequestParam("email") String email) {
                try {
                    authService.resendEmailVerification(email);
                    return ResponseEntity.ok("Verification email sent.");
                } catch (RuntimeException e) {
                    return ResponseEntity.badRequest().body(e.getMessage());
                }
            }
        }
```


2. AuthService.java
```
    java
        package com.lendrix.authservice.service;

        import com.lendrix.authservice.dto.AccountTypeRequest;
        import com.lendrix.authservice.dto.AuthRequest;
        import com.lendrix.authservice.dto.AuthResponse;
        import com.lendrix.authservice.dto.CountrySelectionRequest;
        import com.lendrix.authservice.dto.EmailRegistrationRequest;
        import com.lendrix.authservice.model.User;
        import com.lendrix.authservice.model.VerificationToken;
        import com.lendrix.authservice.repository.UserRepository;
        import com.lendrix.authservice.repository.VerificationTokenRepository;

        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.security.crypto.password.PasswordEncoder;
        import org.springframework.stereotype.Service;

        import java.time.LocalDateTime;
        import java.util.UUID;
        import java.util.Optional;

        /**
        * Enhanced AuthService with proper multi-step registration flow
        * 
        * Registration Steps:
        * 1. Start registration (email + full name)
        * 2. Email verification
        * 3. Account type selection
        * 4. Country selection  
        * 5. Phone verification initiation
        * 6. Phone verification confirmation
        * 7. Password creation and finalization
        * 
        * @author Dorsphil Osei <dorsphillloseiasuming@gmail.com>
        */
        @Service
        public class AuthService {

            @Autowired
            private UserRepository userRepository;

            @Autowired
            private VerificationTokenRepository tokenRepository;

            @Autowired
            private EmailService emailService;

            private final PasswordEncoder passwordEncoder;

            public AuthService(PasswordEncoder passwordEncoder) {
                this.passwordEncoder = passwordEncoder;
            }

            // ============= LEGACY SINGLE-STEP REGISTRATION =============
            
            /**
            * Legacy single-step registration
            * @deprecated Use startRegistration() for multi-step flow
            */
            @Deprecated
            public AuthResponse register(AuthRequest request) {
                if (userRepository.findByEmail(request.getEmail()).isPresent()) {
                    return new AuthResponse("User already exists");
                }

                User user = new User();
                user.setEmail(request.getEmail());
                user.setPassword(passwordEncoder.encode(request.getPassword()));
                user.setFullName(request.getFullName());
                user.setEmailVerified(false);

                String token = UUID.randomUUID().toString();
                VerificationToken verificationToken = new VerificationToken();
                verificationToken.setToken(token);
                verificationToken.setUser(user);
                verificationToken.setExpiryDate(LocalDateTime.now().plusMinutes(10));
                tokenRepository.save(verificationToken);

                emailService.sendVerificationEmail(user, token);
                
                return new AuthResponse("Registration successful. Please check your email to verify your account.");
            }

            /**
            * User login
            */
            public AuthResponse login(AuthRequest request) {
                return userRepository.findByEmail(request.getEmail())
                        .map(user -> {
                            if (!user.isEmailVerified()) {
                                return new AuthResponse("Please verify your email first");
                            }
                            if (passwordEncoder.matches(request.getPassword(), user.getPassword())) {
                                return new AuthResponse("Login successful");
                            } else {
                                return new AuthResponse("Invalid password");
                            }
                        })
                        .orElse(new AuthResponse("User not found"));
            }

            // ============= MULTI-STEP REGISTRATION FLOW =============

            /**
            * STEP 1: Start registration with email and full name
            * Creates incomplete user record and sends email verification
            */
            public AuthResponse startRegistration(EmailRegistrationRequest request) {
                // Check if user already exists
                if (userRepository.findByEmail(request.getEmail()).isPresent()) {
                    throw new RuntimeException("An account with this email already exists");
                }

                // Create new user with minimal information
                User user = new User();
                user.setEmail(request.getEmail());
                user.setFullName(request.getFullName());
                user.setEmailVerified(false);
                user.setPhoneVerified(false);
                // Note: No password set yet - this happens in finalization
                
                userRepository.save(user);

                // Generate and save verification token
                String token = UUID.randomUUID().toString();
                VerificationToken verificationToken = new VerificationToken();
                verificationToken.setToken(token);
                verificationToken.setUser(user);
                verificationToken.setExpiryDate(LocalDateTime.now().plusMinutes(15)); // 15 minutes for email verification
                tokenRepository.save(verificationToken);

                // Send verification email
                emailService.sendVerificationEmail(user, token);

                return new AuthResponse("Registration started successfully. Please check your email to verify your account.");
            }

            /**
            * STEP 3: Save account type (Personal or Business)
            * Requires email to be verified first
            */
            public AuthResponse saveAccountType(AccountTypeRequest request) {
                Optional<User> optionalUser = userRepository.findByEmail(request.getEmail());
                
                if (optionalUser.isEmpty()) {
                    throw new RuntimeException("User not found. Please start registration first.");
                }

                User user = optionalUser.get();
                
                // Validate prerequisites
                if (!user.isEmailVerified()) {
                    throw new RuntimeException("Please verify your email address first.");
                }

                // Validate account type
                String accountType = request.getAccountType();
                if (!"Personal".equalsIgnoreCase(accountType) && !"Business".equalsIgnoreCase(accountType)) {
                    throw new RuntimeException("Account type must be either 'Personal' or 'Business'.");
                }

                user.setAccountType(accountType);
                userRepository.save(user);

                return new AuthResponse("Account type saved successfully.");
            }

            /**
            * STEP 4: Save country of residence
            * Requires email verification and account type selection
            */
            public AuthResponse saveCountryOfResidence(CountrySelectionRequest request) {
                Optional<User> optionalUser = userRepository.findByEmail(request.getEmail());
                
                if (optionalUser.isEmpty()) {
                    throw new RuntimeException("User not found. Please start registration first.");
                }

                User user = optionalUser.get();
                
                // Validate prerequisites
                if (!user.isEmailVerified()) {
                    throw new RuntimeException("Please verify your email address first.");
                }
                
                if (user.getAccountType() == null || user.getAccountType().trim().isEmpty()) {
                    throw new RuntimeException("Please select an account type first.");
                }

                user.setCountryOfResidence(request.getCountry());
                userRepository.save(user);

                return new AuthResponse("Country of residence saved successfully.");
            }

            /**
            * Validate prerequisites for phone verification step
            */
            public void validatePhoneVerificationPrerequisites(String email) {
                Optional<User> optionalUser = userRepository.findByEmail(email);
                
                if (optionalUser.isEmpty()) {
                    throw new RuntimeException("User not found. Please start registration first.");
                }

                User user = optionalUser.get();
                
                if (!user.isEmailVerified()) {
                    throw new RuntimeException("Please verify your email address first.");
                }
                
                if (user.getAccountType() == null || user.getAccountType().trim().isEmpty()) {
                    throw new RuntimeException("Please select an account type first.");
                }
                
                if (user.getCountryOfResidence() == null || user.getCountryOfResidence().trim().isEmpty()) {
                    throw new RuntimeException("Please select your country of residence first.");
                }
            }

            /**
            * STEP 7: Finalize registration with password
            * Completes the entire registration process
            */
            public void finalizeRegistration(String email, String password) {
                Optional<User> optionalUser = userRepository.findByEmail(email);

                if (optionalUser.isEmpty()) {
                    throw new RuntimeException("User not found. Please start registration first.");
                }

                User user = optionalUser.get();

                // Validate all prerequisites are completed
                if (!user.isEmailVerified()) {
                    throw new RuntimeException("Please verify your email address first.");
                }
                
                if (user.getAccountType() == null || user.getAccountType().trim().isEmpty()) {
                    throw new RuntimeException("Please select an account type first.");
                }
                
                if (user.getCountryOfResidence() == null || user.getCountryOfResidence().trim().isEmpty()) {
                    throw new RuntimeException("Please select your country of residence first.");
                }

                if (!user.isPhoneVerified()) {
                    throw new RuntimeException("Please verify your phone number first.");
                }

                // Validate password strength (basic validation)
                if (password == null || password.length() < 8) {
                    throw new RuntimeException("Password must be at least 8 characters long.");
                }

                // Set encrypted password
                user.setPassword(passwordEncoder.encode(password));
                userRepository.save(user);
            }

            // ============= UTILITY METHODS =============

            /**
            * Get current registration status for a user
            */
            public AuthResponse getRegistrationStatus(String email) {
                Optional<User> optionalUser = userRepository.findByEmail(email);
                
                if (optionalUser.isEmpty()) {
                    throw new RuntimeException("User not found.");
                }

                User user = optionalUser.get();
                StringBuilder status = new StringBuilder("Registration Progress: ");
                
                if (!user.isEmailVerified()) {
                    status.append("Email verification pending");
                } else if (user.getAccountType() == null) {
                    status.append("Account type selection pending");
                } else if (user.getCountryOfResidence() == null) {
                    status.append("Country selection pending");
                } else if (!user.isPhoneVerified()) {
                    status.append("Phone verification pending");
                } else if (user.getPassword() == null) {
                    status.append("Password creation pending");
                } else {
                    status.append("Registration complete");
                }

                return new AuthResponse(status.toString());
            }

            /**
            * Resend email verification token
            */
            public void resendEmailVerification(String email) {
                Optional<User> optionalUser = userRepository.findByEmail(email);
                
                if (optionalUser.isEmpty()) {
                    throw new RuntimeException("User not found.");
                }

                User user = optionalUser.get();
                
                if (user.isEmailVerified()) {
                    throw new RuntimeException("Email is already verified.");
                }

                // Delete any existing tokens for this user
                tokenRepository.findByToken(user.getEmail()).ifPresent(tokenRepository::delete);

                // Generate new token
                String token = UUID.randomUUID().toString();
                VerificationToken verificationToken = new VerificationToken();
                verificationToken.setToken(token);
                verificationToken.setUser(user);
                verificationToken.setExpiryDate(LocalDateTime.now().plusMinutes(15));
                tokenRepository.save(verificationToken);

                // Send verification email
                emailService.sendVerificationEmail(user, token);
            }
        }
```

3. PhoneVerificationCode.java
```
    java
        package com.lendrix.authservice.model;

        import jakarta.persistence.*;
        import lombok.AllArgsConstructor;
        import lombok.Builder;
        import lombok.Data;
        import lombok.NoArgsConstructor;

        import java.time.LocalDateTime;

        /**
        * Entity representing a phone verification code sent to users for phone number verification.
        * 
        * @author Dorsphil Osei <dorsphillloseiasuming@gmail.com>
        */
        @Entity
        @Table(name = "phone_verification_codes")
        @Data
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        public class PhoneVerificationCode {
            
            @Id
            @GeneratedValue(strategy = GenerationType.IDENTITY)
            private Long id;
            
            /**
            * The phone number that the verification code was sent to
            */
            @Column(nullable = false)
            private String phoneNumber;
            
            /**
            * The 6-digit verification code
            */
            @Column(nullable = false)
            private String code;
            
            /**
            * When this code expires
            */
            @Column(nullable = false)
            private LocalDateTime expiryTime;
            
            /**
            * The user this verification code belongs to
            */
            @ManyToOne(fetch = FetchType.LAZY)
            @JoinColumn(name = "user_id", nullable = false)
            private User user;
        }
```

4. PhoneVerificationCodeRepository.java
```
    java
        package com.lendrix.authservice.repository;

        import com.lendrix.authservice.model.PhoneVerificationCode;
        import org.springframework.data.jpa.repository.JpaRepository;
        import org.springframework.stereotype.Repository;

        import java.util.Optional;

        /**
        * Repository interface for managing PhoneVerificationCode entities.
        * 
        * @author Dorsphil Osei <dorsphillloseiasuming@gmail.com>
        */
        @Repository
        public interface PhoneVerificationCodeRepository extends JpaRepository<PhoneVerificationCode, Long> {
            
            /**
            * Find a phone verification code by phone number
            * 
            * @param phoneNumber the phone number to search for
            * @return Optional containing the verification code if found
            */
            Optional<PhoneVerificationCode> findByPhoneNumber(String phoneNumber);
            
            /**
            * Find a phone verification code by user email (through user relationship)
            * 
            * @param email the user's email
            * @return Optional containing the verification code if found
            */
            Optional<PhoneVerificationCode> findByUserEmail(String email);
        }
```

## KEY CHANGES MADE
**Step Validation**
- Each step now validates that previous steps are completed before proceeding.

**Registration State Management**
- Users are created in Step 1 with minimal information
- Each subsequent step adds more data
- Password is only set in the final step
- Proper error handling for incomplete registrations

**Additional Features**
- Registration status checking
- Email verification resend capability
- Better error messages
- Proper cleanup of verification tokens

**TESTED THE ABOVE CHANGES WITH POSTMAN**


## LOGIN
 **Lendrix Login + 2FA Flow**
1.  Login Request (email + password)
    POST /api/auth/login
    
    - Check if user exists
    - Check if password matches (BCrypt)
On success:
- Trigger system notification OR
- Show 2FA method selection screen

2.  System Notification (default 2FA)
For now, we'll simulate this "trusted device notification" with a dummy success message.
Later, this could be integrated with:
* Firebase Cloud Messaging (for mobile push)
* OR Local notification on device (for app)

3.  "Verify another way" - 2FA Options
    User can pick:
    a. Get code by SMS (Primary phone already in DB from registration)
    - Send 6-digit code
    - Save it with expiry

Endpoint: POST /api/auth/2fa/send-code

b. Resend App Notification
Same as step 2 (repeat trigger)

4. Enter SMS Code
Endpoint: POST /api/auth/2fa/verify-code
If valid:
- Login success
- Generate + return JWT


## Step 1:Login (email + password)
- Email lookup
- Password verification (BCrypt)
- Response: success = prompt 2FA
- Response: failure = error message

1. Create LoginResponse.java
src/main/java/com/lendrix/authservice/dto/LoginRequest.java

```
    java
        package com.lendrix.authservice.dto;

        /**
        * DTO for login request containing user email and password.
        */
        public class LoginRequest {
            private String email;
            private String password;

            // Constructors
            public LoginRequest() {}
            
            public LoginRequest(String email, String password) {
                this.email = email;
                this.password = password;
            }

            // Getters and Setters
            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }

            public String getPassword() {
                return password;
            }

            public void setPassword(String password) {
                this.password = password;
            }
        }
```
2. Create a LoginResponse.java file
src/main/java/com/lendrix/authservice/dto/LoginResponse.java
```
    java
    package com.lendrix.authservice.dto;

    /**
    * DTO for login response after credentials are verified.
    */
    public class LoginResponse {
        private String message;

        public LoginResponse() {}

        public LoginResponse(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
```
3. Update AuthController.java
src/main/java/com/lendrix/authservice/controller/AuthController.java
```
    java
        @PostMapping("/login")
        public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
            return authService.login(request);
        }
```
4.  Update AuthService.java 
src/main/java/com/lendrix/authservice/service/AuthService.java
- Add login method 
```
    java
        /**
        * Verifies email and password during login.
        *
        * @param request LoginRequest containing email and password.
        * @return ResponseEntity with a message about 2FA or failure.
        */
        public ResponseEntity<LoginResponse> login(LoginRequest request) {
            Optional<User> userOpt = userRepository.findByEmail(request.getEmail());
            
            if (userOpt.isEmpty()) {
                return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(new LoginResponse("Invalid credentials"));
            }

            User user = userOpt.get();

            // Check if email is verified
            if (!user.isEmailVerified()) {
                return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(new LoginResponse("Email not verified. Please verify your email."));
            }

            // Check password
            if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
                return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(new LoginResponse("Invalid credentials"));
            }

            // Simulate sending system notification (placeholder for now)
            return ResponseEntity.ok(
                new LoginResponse("Login successful. Notification sent to your trusted device.")
            );
        }
```
5. POSTMAN TEST
- Method: POST
- URL: http://localhost:8081/api/auth/login
- Body (JSON):
```
    {
        "email": "johndoe@example.com",
        "password": "yourPlainTextPassword"
    }
```
```
    **Expected Responses:**
    Case	                    Response	                                                    Status

    1.Correct email + password	"Login successful. Notification sent to your trusted device."	200 OK
    2.Wrong password	        "Invalid credentials"	                                        401
    3.Non-existing email	    "Invalid credentials"	                                        401
    4.Email not verified	    "Email not verified. Please verify your email."                 403
```


## Step 2: “Verify another way” → Send 6-digit SMS code

1. Create DTO: TwoFactorCodeRequest.java
src/main/java/com/lendrix/authservice/dto/TwoFactorCodeRequest.java
```
    java

        package com.lendrix.authservice.dto;

        /**
        * DTO for requesting a 2FA code via SMS.
        */
        public class TwoFactorCodeRequest {
            private String email;

            public TwoFactorCodeRequest() {
            }

            public TwoFactorCodeRequest(String email) {
                this.email = email;
            }

            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }
        }
```
2. Reuse PhoneVerificationCode.java

3. Create Service: TwoFactorService.java
src/main/java/com/lendrix/authservice/service/TwoFactorService.java
```
    java
        package com.lendrix.authservice.service;

        import com.lendrix.authservice.dto.TwoFactorCodeRequest;
        import com.lendrix.authservice.model.PhoneVerificationCode;
        import com.lendrix.authservice.model.User;
        import com.lendrix.authservice.repository.PhoneVerificationCodeRepository;
        import com.lendrix.authservice.repository.UserRepository;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.http.ResponseEntity;
        import org.springframework.stereotype.Service;

        import java.time.LocalDateTime;
        import java.util.Optional;
        import java.util.Random;

        /**
        * Service class for handling two-factor authentication via SMS.
        */
        @Service
        public class TwoFactorService {

            @Autowired
            private UserRepository userRepository;

            @Autowired
            private PhoneVerificationCodeRepository codeRepository;

            public ResponseEntity<String> sendCode(TwoFactorCodeRequest request) {
                Optional<User> userOpt = userRepository.findByEmail(request.getEmail());

                if (userOpt.isEmpty()) {
                    return ResponseEntity.badRequest().body("User not found");
                }

                User user = userOpt.get();

                if (user.getPhoneNumber() == null || user.getPhoneNumber().isEmpty()) {
                    return ResponseEntity.badRequest().body("User has no phone number registered.");
                }

                String code = String.format("%06d", new Random().nextInt(999999));
                LocalDateTime expiry = LocalDateTime.now().plusMinutes(5);

                PhoneVerificationCode codeEntity = new PhoneVerificationCode();
                codeEntity.setPhoneNumber(user.getPhoneNumber());
                codeEntity.setCode(code);
                codeEntity.setExpiry(expiry);

                codeRepository.save(codeEntity);

                // Simulate SMS send
                System.out.println("Sending 2FA code to " + user.getPhoneNumber() + ": " + code);

                return ResponseEntity.ok("Verification code sent to your phone.");
            }
        }
```

4. Create Controller: TwoFactorController.java
src/main/java/com/lendrix/authservice/controller/TwoFactorController.java
```
    java
    package com.lendrix.authservice.controller;

        import com.lendrix.authservice.dto.TwoFactorCodeRequest;
        import com.lendrix.authservice.dto.TwoFactorVerifyRequest;
        import com.lendrix.authservice.service.TwoFactorService;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.http.ResponseEntity;
        import org.springframework.web.bind.annotation.*;

        /**
        * Controller for handling 2FA options and verification.
        */
        @RestController
        @RequestMapping("/api/auth/2fa")
        public class TwoFactorController {

            @Autowired
            private TwoFactorService twoFactorService;

            @PostMapping("/send-code")
            public ResponseEntity<String> sendCode(@RequestBody TwoFactorCodeRequest request) {
                return twoFactorService.sendCode(request);
            }

            @PostMapping("/verify-code")
            public ResponseEntity<String> verifyCode(@RequestBody TwoFactorVerifyRequest request) {
                return twoFactorService.verifyCode(request);
            }
        }
```

5. Create DTO: TwoFactorVerifyRequest.java
src/main/java/com/lendrix/authservice/dto/TwoFactorVerifyRequest.java
```
    java
        package com.lendrix.authservice.dto;

        /**
        * Data Transfer Object (DTO) representing a request to verify a two-factor authentication (2FA) code.
        * <p>
        * This DTO contains the user's email address and the 6-digit SMS code that the user received
        * and wishes to verify as part of the authentication process.
        * </p>
        */
        public class TwoFactorVerifyRequest {
            private String email;
            private String code;

            /**
            * Default constructor.
            * Required for frameworks that instantiate the object via reflection.
            */
            public TwoFactorVerifyRequest() {
            }

            /**
            * Constructs a TwoFactorVerifyRequest with the specified email and verification code.
            *
            * @param email the email address of the user attempting verification
            * @param code  the 6-digit SMS verification code to verify
            */
            public TwoFactorVerifyRequest(String email, String code) {
                this.email = email;
                this.code = code;
            }

            /**
            * Returns the email address associated with this verification request.
            *
            * @return the user's email address as a String
            */
            public String getEmail() {
                return email;
            }

            /**
            * Sets the email address for this verification request.
            *
            * @param email the user's email address to set
            */
            public void setEmail(String email) {
                this.email = email;
            }

            /**
            * Returns the 6-digit SMS verification code.
            *
            * @return the verification code as a String
            */
            public String getCode() {
                return code;
            }

            /**
            * Sets the 6-digit SMS verification code.
            *
            * @param code the verification code to set
            */
            public void setCode(String code) {
                this.code = code;
            }
        }
```

6.  Add Verify Code Logic: TwoFactorService.java
    Add this method;
```
    java
            public ResponseEntity<String> verifyCode(TwoFactorVerifyRequest request) {
            Optional<User> userOpt = userRepository.findByEmail(request.getEmail());

            if (userOpt.isEmpty()) {
                return ResponseEntity.badRequest().body("User not found");
            }

            User user = userOpt.get();

            Optional<PhoneVerificationCode> codeOpt =
                    codeRepository.findTopByPhoneNumberOrderByExpiryDesc(user.getPhoneNumber());

            if (codeOpt.isEmpty()) {
                return ResponseEntity.badRequest().body("No verification code found.");
            }

            PhoneVerificationCode codeEntity = codeOpt.get();

            if (!codeEntity.getCode().equals(request.getCode())) {
                return ResponseEntity.badRequest().body("Invalid verification code.");
            }

            if (codeEntity.getExpiry().isBefore(LocalDateTime.now())) {
                return ResponseEntity.badRequest().body("Verification code has expired.");
            }

            // SIMULATE login success & JWT generation
            return ResponseEntity.ok("Login complete. Welcome to your Lendrix account.");
        }
```


**POSTMAN TEST**
- Send Code
POST /api/auth/2fa/send-code
```
    json

        {
        "email": "johndoe@example.com"
        }
```

- Expected: 200 OK
  Message: "Verification code sent to your phone."


- Verify Code
POST /api/auth/2fa/verify-code

```
    json

        {
        "email": "johndoe@example.com",
        "code": "123456"
        }
```
- Expected: 200 OK
  Message: "Login complete. Welcome to your Lendrix account."

  ## Step 3: Confirm User

  **This step confirms user, using registration passcode i.e if user**
  **is unable to confirm through system notification and "receive code by text"**

  1. Edit Registration Flow
    - Create new field in User.java: passcode

    - New DTO: RegistrationPasscodeRequest.java

    - New endpoint: POST /api/auth/register/passcode

    - Save the 4-digit passcode (with validation) 

*A. Update User.java*
```
    java
        @Column(name = "passcode")
        private String passcode;

        public String getPasscode() {
            return passcode;
        }

        public void setPasscode(String passcode) {
            this.passcode = passcode;
        }
```
*B. Create a DTO RegistrationPasscodeRequest.java*
```
    java
        package com.lendrix.authservice.dto;

        /**
        * DTO to receive the 4-digit passcode from user during registration.
        */
        public class RegistrationPasscodeRequest {
            private String email;
            private String passcode;

            public RegistrationPasscodeRequest() {}

            public RegistrationPasscodeRequest(String email, String passcode) {
                this.email = email;
                this.passcode = passcode;
            }

            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }

            public String getPasscode() {
                return passcode;
            }

            public void setPasscode(String passcode) {
                this.passcode = passcode;
            }
        }
```

*C. Add Controller Endpoint in AuthController.java*
```
    java
        @PostMapping("/register/passcode")
        public ResponseEntity<String> savePasscode(@RequestBody RegistrationPasscodeRequest request) {
            return authService.savePasscode(request);
        }
```
*D Add Logic in Service(AuthService.java)*
```
    java
        public ResponseEntity<String> savePasscode(RegistrationPasscodeRequest request) {
        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());

        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("User not found");
        }

        User user = userOpt.get();

        String passcode = request.getPasscode();

        if (passcode == null || !passcode.matches("\\d{4}")) {
            return ResponseEntity.badRequest().body("Passcode must be a 4-digit number.");
        }

        user.setPasscode(passcode);
        userRepository.save(user);

        return ResponseEntity.ok("Passcode saved successfully.");
    }
```

2. LOGIN SIDE (Passcode Recovery)

*A. Create DTO: PasscodeLoginRequest.java*
```
    java
        package com.lendrix.authservice.dto;

        /**
        * DTO for login recovery via passcode.
        */
        public class PasscodeLoginRequest {
            private String email;
            private String passcode;

            public PasscodeLoginRequest() {}

            public PasscodeLoginRequest(String email, String passcode) {
                this.email = email;
                this.passcode = passcode;
            }

            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }

            public String getPasscode() {
                return passcode;
            }

            public void setPasscode(String passcode) {
                this.passcode = passcode;
            }
        }
```

*B. Add Controller: TwoFactorController.java*
```
    java
        @PostMapping("/passcode-login")
        public ResponseEntity<String> loginWithPasscode(@RequestBody PasscodeLoginRequest request) {
            return twoFactorService.loginWithPasscode(request);
        }
```
*C.  Add Logic: TwoFactorService.java*
```
    java
        public ResponseEntity<String> loginWithPasscode(PasscodeLoginRequest request) {
        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());

        if (userOpt.isEmpty()) {
            return ResponseEntity.badRequest().body("User not found.");
        }

        User user = userOpt.get();

        if (user.getPasscode() == null) {
            return ResponseEntity.badRequest().body("No passcode found for this user.");
        }

        if (!user.getPasscode().equals(request.getPasscode())) {
            return ResponseEntity.badRequest().body("Invalid passcode.");
        }

        // Simulate login success
        return ResponseEntity.ok("Login successful via passcode. Welcome back.");
    }
```

 POSTMAN TEST
1. Save Passcode
POST /api/auth/register/passcode
```
    {
    "email": "johndoe@example.com",
    "passcode": "1234"
    }
```
Expected: 200 OK, "Passcode saved successfully."

2. Login via Passcode (fallback)
POST /api/auth/2fa/passcode-login
```
    {
    "email": "johndoe@example.com",
    "passcode": "1234"
    }
```
Expected: 200 OK, "Login successful via passcode. Welcome back."


## SIGN-IN VIA GOOGLE
1. Receive idToken from frontend (obtained from Google Sign-In SDK)
2. Verify the token with Google
3. Extract Google account info: email, name, etc.
4. If user exists → generate JWT and return
5. If user doesn't exist → create user, generate JWT, return

# Step 1: Add dependencies in pom.xml
```
    xml
        <dependency>
        <groupId>com.google.api-client</groupId>
        <artifactId>google-api-client</artifactId>
        <version>2.2.0</version>
    </dependency>
    <dependency>
        <groupId>com.google.oauth-client</groupId>
        <artifactId>google-oauth-client-jetty</artifactId>
        <version>2.2.0</version>
    </dependency>
```

# Step 2:  Create DTO;GoogleSignInRequest.java
```
    java
        package com.lendrix.authservice.dto;

        /**
        * DTO to receive the Google ID token from the client.
        */
        public class GoogleSignInRequest {
            private String idToken;

            public GoogleSignInRequest() {}

            public GoogleSignInRequest(String idToken) {
                this.idToken = idToken;
            }

            public String getIdToken() {
                return idToken;
            }

            public void setIdToken(String idToken) {
                this.idToken = idToken;
            }
        }
```
# Step 3:   Add Controller Endpoint to AuthController.java
```
    java
        @PostMapping("/google-signin")
        public ResponseEntity<?> googleSignIn(@RequestBody GoogleSignInRequest request) {
            return authService.googleSignIn(request);
        }
```

# Step 4:   Add Service Logic to AuthService.java
```
    java
        import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
        import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
        import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken.Payload;
        import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
        import com.google.api.client.json.jackson2.JacksonFactory;

        // ...

        public ResponseEntity<?> googleSignIn(GoogleSignInRequest request) {
            try {
                JacksonFactory jsonFactory = JacksonFactory.getDefaultInstance();
                GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(GoogleNetHttpTransport.newTrustedTransport(), jsonFactory)
                        .setAudience(Collections.singletonList("YOUR_CLIENT_ID.apps.googleusercontent.com"))
                        .build();

                GoogleIdToken idToken = verifier.verify(request.getIdToken());

                if (idToken != null) {
                    Payload payload = idToken.getPayload();

                    String email = payload.getEmail();
                    String fullName = (String) payload.get("name");

                    Optional<User> userOpt = userRepository.findByEmail(email);

                    User user;
                    if (userOpt.isPresent()) {
                        user = userOpt.get();
                    } else {
                        // New user, create one with default values
                        user = new User();
                        user.setEmail(email);
                        user.setFullName(fullName);
                        user.setEmailVerified(true); // Assume Google email is verified
                        user.setPassword(null); // No password needed for Google login
                        userRepository.save(user);
                    }

                    // Simulate JWT creation
                    String fakeJwt = "jwt_token_for_" + user.getEmail();

                    return ResponseEntity.ok(Map.of(
                            "message", "Login successful via Google",
                            "jwt", fakeJwt,
                            "email", email,
                            "fullName", user.getFullName()
                    ));
                } else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Google ID token.");
                }
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Google login failed.");
            }
        }
```

# PARTIAL POSTMAN TEST WHILE FRONTEND REGISTERS WITH GOOGLE CONSOLE AND GETS A CLIENT ID
Request:
```
    bash
        POST http://localhost:8081/api/auth/google-signin
        Content-Type: application/json

        {
        "idToken": "FAKE-TOKEN-123"
        }
```
You can use any string as the idToken for now — e.g., "FAKE-TOKEN-123" or "simulatedIdToken"

**Expected Output (Backend Working Correctly)**
    {
    "timestamp": "2025-06-23T...",
    "status": 401,
    "error": "Unauthorized",
    "message": "Invalid Google ID token."
    }

## SIGN-IN VIA GOOGLE USING FIREBASE AUTHENTICATION 

# Firebase Google Sign-In Flow
1. Verify Firebase token
    - Use Firebase Admin SDK
    - Confirm it’s a valid Firebase-issued token
    - Extract user info (email, name)
 2. Check if user exists
    - If yes → log in and return JWT
    - If no → create user + return JWT

# Step 1:    1. Add Firebase Admin SDK in pom.xml:
```
xml 
    <dependency>
    <groupId>com.google.firebase</groupId>
    <artifactId>firebase-admin</artifactId>
    <version>9.2.0</version>
    </dependency>
```

# Step 2:   Initialize Firebase Admin SDK
Create a config class (e.g. FirebaseConfig.java):
```
    java
    package com.lendrix.authservice.config;

    import com.google.auth.oauth2.GoogleCredentials;
    import com.google.firebase.FirebaseApp;
    import com.google.firebase.FirebaseOptions;
    import org.springframework.context.annotation.Configuration;

    import javax.annotation.PostConstruct;
    import java.io.FileInputStream;
    import java.io.IOException;

    @Configuration
    public class FirebaseConfig {

        @PostConstruct
        public void init() throws IOException {
            FileInputStream serviceAccount = new FileInputStream("firebase-admin-sdk.json");

            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .build();

            if (FirebaseApp.getApps().isEmpty()) {
                FirebaseApp.initializeApp(options);
            }
        }
    }
```
# Step 3:   Add DTO FirebaseLoginRequest.java
```
    package com.lendrix.authservice.dto;

    /**
    * DTO for receiving a Firebase ID token from the frontend
    * during Google Sign-In via Firebase Authentication.
    */
    public class FirebaseLoginRequest {

        /**
        * Firebase-issued ID token obtained after user logs in with Google.
        */
        private String firebaseToken;

        public FirebaseLoginRequest() {
        }

        public FirebaseLoginRequest(String firebaseToken) {
            this.firebaseToken = firebaseToken;
        }

        public String getFirebaseToken() {
            return firebaseToken;
        }

        public void setFirebaseToken(String firebaseToken) {
            this.firebaseToken = firebaseToken;
        }
    }
```


# Step 4:   Add endpoint in AuthController.java
```
    @PostMapping("/firebase-login")
    public ResponseEntity<?> firebaseLogin(@RequestBody FirebaseLoginRequest request) {
        return authService.firebaseLogin(request);
    }
```
# Step 5:   Add logic to AuthService.java
```
    java
        public ResponseEntity<?> firebaseLogin(FirebaseLoginRequest request) {
    try {
        FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(request.getFirebaseToken());

        String email = decodedToken.getEmail();
        String name = (String) decodedToken.getClaims().get("name");

        Optional<User> userOpt = userRepository.findByEmail(email);
        User user;

        if (userOpt.isPresent()) {
            user = userOpt.get();
        } else {
            user = new User();
            user.setEmail(email);
            user.setFullName(name);
            user.setEmailVerified(true);
            userRepository.save(user);
        }

        // Simulate JWT generation
        String fakeJwt = "jwt_token_for_" + email;

        return ResponseEntity.ok(Map.of(
                "message", "Login successful via Firebase",
                "jwt", fakeJwt
        ));
    } catch (FirebaseAuthException e) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid Firebase token.");
    }
}
```

## FORGOT PASSWORD FLOW SUMMARY
*Step 1: User enters registration passcode*
- Validate if it matches for the email

*Step 2: User types new password and confirm password*
- Backend checks if they match
- If they match → hash and save as new password
- Log user in (simulate with success response or JWT)

1. Create DTO: ForgotPasswordRequest.java
```
    java
        package com.lendrix.authservice.dto;

        /**
        * DTO for handling forgot password reset using registration passcode.
        */
        public class ForgotPasswordRequest {
            private String email;
            private String passcode;
            private String newPassword;
            private String confirmPassword;

            public ForgotPasswordRequest() {
            }

            public ForgotPasswordRequest(String email, String passcode, String newPassword, String confirmPassword) {
                this.email = email;
                this.passcode = passcode;
                this.newPassword = newPassword;
                this.confirmPassword = confirmPassword;
            }

            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }

            public String getPasscode() {
                return passcode;
            }

            public void setPasscode(String passcode) {
                this.passcode = passcode;
            }

            public String getNewPassword() {
                return newPassword;
            }

            public void setNewPassword(String newPassword) {
                this.newPassword = newPassword;
            }

            public String getConfirmPassword() {
                return confirmPassword;
            }

            public void setConfirmPassword(String confirmPassword) {
                this.confirmPassword = confirmPassword;
            }
        }
```
2. Add Controller Endpoint in AuthController.java
```
    java
        @PostMapping("/forgot-password")
        public ResponseEntity<?> resetPassword(@RequestBody ForgotPasswordRequest request) {
            return authService.resetPasswordWithPasscode(request);
        }
```
3. Service Logic in AuthService.java
```
    public ResponseEntity<?> resetPasswordWithPasscode(ForgotPasswordRequest request) {
    Optional<User> userOpt = userRepository.findByEmail(request.getEmail());

    if (userOpt.isEmpty()) {
        return ResponseEntity.badRequest().body("User not found.");
    }

    User user = userOpt.get();

    if (user.getPasscode() == null || !user.getPasscode().equals(request.getPasscode())) {
        return ResponseEntity.badRequest().body("Invalid registration passcode.");
    }

    String newPassword = request.getNewPassword();
    String confirmPassword = request.getConfirmPassword();

    if (!newPassword.equals(confirmPassword)) {
        return ResponseEntity.badRequest().body("Passwords do not match.");
    }

    // Password valid and matches, now encode and update
    String hashedPassword = passwordEncoder.encode(newPassword);
    user.setPassword(hashedPassword);

    userRepository.save(user);

    return ResponseEntity.ok("Password reset successful. You are now logged in.");
}
```

# POSTMAN TEST
URL: POST /api/auth/forgot-password
Body (JSON):
```
    json
        {
        "email": "johndoe@example.com",
        "passcode": "1234",
        "newPassword": "securePassword",
        "confirmPassword": "securePassword"
        }
```
Expected:
```
    json
    {
    "message": "Password reset successful. You are now logged in."
    }
```
 * If passcode wrong → "Invalid registration passcode."
 * If passwords mismatch → "Passwords do not match."






























